<?php
session_start();
require_once("config.php");
require_once("functions.php");

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$role = $_SESSION['role'];
$username = $_SESSION['username'];

// Get data untuk dashboard
$interfaces = getInterfaces();
$hotspotData = getHotspotRealTimeData();
$activeUsers = $hotspotData['active_users'];
$statistics = $hotspotData['statistics'];
$bandwidthSummary = $hotspotData['bandwidth_summary'];

// Data untuk charts
$hourlyData = [];
$interfaceStats = [];
$userActivityData = [];

// Generate hourly data (mock data untuk demo)
for ($i = 23; $i >= 0; $i--) {
    $hour = date('H:i', strtotime("-{$i} hours"));
    $hourlyData['labels'][] = $hour;
    $hourlyData['users'][] = rand(5, 25);
    $hourlyData['bandwidth'][] = rand(10, 100);
}

// Interface statistics
$runningInterfaces = count(array_filter($interfaces, function($i) { return $i['running'] == 'true'; }));
$stoppedInterfaces = count($interfaces) - $runningInterfaces;
$interfaceStats = [$runningInterfaces, $stoppedInterfaces];

// Top users data
$topUsers = array_slice($activeUsers, 0, 5);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard MikroTik Monitor</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="sidebar.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <meta http-equiv="refresh" content="60">
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background: #f8fafc;
            color: #1e293b;
        }
        
        .content-wrapper {
            padding: 20px;
            max-width: 1400px;
            margin: 0 auto;
        }
        
        /* Header */
        .dashboard-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 16px;
            padding: 30px;
            margin-bottom: 30px;
            color: white;
            position: relative;
            overflow: hidden;
        }
        
        .dashboard-header::before {
            content: '';
            position: absolute;
            top: 0;
            right: 0;
            width: 200px;
            height: 200px;
            background: rgba(255,255,255,0.1);
            border-radius: 50%;
            transform: translate(50px, -50px);
        }
        
        .header-content {
            position: relative;
            z-index: 2;
        }
        
        .header-title {
            font-size: 32px;
            font-weight: 700;
            margin-bottom: 8px;
        }
        
        .header-subtitle {
            font-size: 16px;
            opacity: 0.9;
            margin-bottom: 20px;
        }
        
        .header-stats {
            display: flex;
            gap: 30px;
            flex-wrap: wrap;
        }
        
        .header-stat {
            text-align: center;
        }
        
        .header-stat-number {
            font-size: 28px;
            font-weight: 700;
            display: block;
        }
        
        .header-stat-label {
            font-size: 14px;
            opacity: 0.8;
        }
        
        /* Stats Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: white;
            border-radius: 12px;
            padding: 24px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            border: 1px solid #e2e8f0;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }
        
        .stat-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
        }
        
        .stat-card-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 16px;
        }
        
        .stat-icon {
            width: 48px;
            height: 48px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            color: white;
        }
        
        .stat-icon.users { background: linear-gradient(135deg, #667eea, #764ba2); }
        .stat-icon.active { background: linear-gradient(135deg, #f093fb, #f5576c); }
        .stat-icon.bandwidth { background: linear-gradient(135deg, #4facfe, #00f2fe); }
        .stat-icon.interfaces { background: linear-gradient(135deg, #43e97b, #38f9d7); }
        
        .stat-value {
            font-size: 32px;
            font-weight: 700;
            color: #1e293b;
            margin-bottom: 4px;
        }
        
        .stat-label {
            color: #64748b;
            font-size: 14px;
            font-weight: 500;
        }
        
        .stat-change {
            font-size: 12px;
            font-weight: 600;
            color: #10b981;
        }
        
        /* Charts Grid */
        .charts-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .chart-card {
            background: white;
            border-radius: 12px;
            padding: 24px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            border: 1px solid #e2e8f0;
        }
        
        .chart-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 20px;
        }
        
        .chart-title {
            font-size: 18px;
            font-weight: 600;
            color: #1e293b;
            margin: 0;
        }
        
        .chart-container {
            position: relative;
            height: 300px;
        }
        
        .chart-container.small {
            height: 250px;
        }
        
        /* Bottom Grid */
        .bottom-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }
        
        .info-card {
            background: white;
            border-radius: 12px;
            padding: 24px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            border: 1px solid #e2e8f0;
        }
        
        .info-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 20px;
        }
        
        .info-title {
            font-size: 18px;
            font-weight: 600;
            color: #1e293b;
            margin: 0;
        }
        
        .view-all {
            color: #667eea;
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
        }
        
        .view-all:hover {
            color: #764ba2;
        }
        
        /* User List */
        .user-list {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }
        
        .user-item {
            display: flex;
            align-items: center;
            padding: 12px;
            background: #f8fafc;
            border-radius: 8px;
            transition: background 0.2s ease;
        }
        
        .user-item:hover {
            background: #f1f5f9;
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
            margin-right: 12px;
        }
        
        .user-info {
            flex: 1;
        }
        
        .user-name {
            font-weight: 600;
            color: #1e293b;
            font-size: 14px;
        }
        
        .user-details {
            font-size: 12px;
            color: #64748b;
        }
        
        .user-stats {
            text-align: right;
            font-size: 12px;
        }
        
        .user-usage {
            font-weight: 600;
            color: #1e293b;
        }
        
        .user-time {
            color: #64748b;
        }
        
        /* System Info */
        .system-info {
            display: flex;
            flex-direction: column;
            gap: 16px;
        }
        
        .system-item {
            display: flex;
            align-items: center;
            padding: 12px;
            background: #f8fafc;
            border-radius: 8px;
        }
        
        .system-icon {
            width: 40px;
            height: 40px;
            background: #e2e8f0;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #64748b;
            margin-right: 12px;
        }
        
        .system-details {
            flex: 1;
        }
        
        .system-label {
            font-weight: 600;
            color: #1e293b;
            font-size: 14px;
        }
        
        .system-value {
            font-size: 12px;
            color: #64748b;
        }
        
        .status-badge {
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 11px;
            font-weight: 600;
        }
        
        .status-online {
            background: #dcfce7;
            color: #166534;
        }
        
        .status-offline {
            background: #fef2f2;
            color: #dc2626;
        }
        
        /* Responsive */
        @media (max-width: 1200px) {
            .charts-grid {
                grid-template-columns: 1fr;
            }
        }
        
        @media (max-width: 768px) {
            .content-wrapper {
                padding: 16px;
            }
            
            .dashboard-header {
                padding: 20px;
            }
            
            .header-title {
                font-size: 24px;
            }
            
            .header-stats {
                gap: 20px;
            }
            
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .bottom-grid {
                grid-template-columns: 1fr;
            }
        }
        
        @media (max-width: 480px) {
            .stats-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>

<body>
    <div class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <h3><i class="fas fa-tachometer-alt me-2"></i>DASHBOARD</h3>
        </div>
        <ul class="sidebar-nav">
            <li><a href="index.php" class="active"><span class="icon"><i class="fas fa-tachometer-alt"></i></span>Dashboard</a></li>
            <li><a href="interface.php"><span class="icon"><i class="fas fa-network-wired"></i></span>Network Interface</a></li>
            <li><a href="hotspot.php"><span class="icon"><i class="fas fa-wifi"></i></span>Hotspot Monitor</a></li>
            <li><a href="register_user.php"><span class="icon"><i class="fas fa-user-plus"></i></span>Tambah User</a></li>
            <li><a href="manage_users.php"><span class="icon"><i class="fas fa-users-cog"></i></span>Kelola User</a></li>
            <li><a href="export.php"><span class="icon"><i class="fas fa-download"></i></span>Export Data</a></li>
            <li><a href="logout.php"><span class="icon"><i class="fas fa-sign-out-alt"></i></span>Logout</a></li>
        </ul>
    </div>

    <div class="main-content">
        <div class="content-wrapper">
            <!-- Dashboard Header -->
            <div class="dashboard-header">
                <div class="header-content">
                    <div class="header-title">Dashboard</div>
                    <?php
                        date_default_timezone_set('Asia/Jakarta');
                        echo "Dashboard Monitoring MikroTik - " . date('d F Y, H:i') . " WIB";?>
                    </div>
                </div>
            </div>

            <!-- Stats Cards -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-card-header">
                        <div class="stat-icon users">
                            <i class="fas fa-users"></i>
                        </div>
                        <div class="stat-change">+12% dari kemarin</div>
                    </div>
                    <div class="stat-value"><?= $statistics['total_users'] ?></div>
                    <div class="stat-label">Registered Users</div>
                </div>

                <div class="stat-card">
                    <div class="stat-card-header">
                        <div class="stat-icon active">
                            <i class="fas fa-wifi"></i>
                        </div>
                        <div class="stat-change">+5% dari kemarin</div>
                    </div>
                    <div class="stat-value"><?= $statistics['active_users'] ?></div>
                    <div class="stat-label">Active Sessions</div>
                </div>

                <div class="stat-card">
                    <div class="stat-card-header">
                        <div class="stat-icon bandwidth">
                            <i class="fas fa-chart-line"></i>
                        </div>
                        <div class="stat-change">+8% dari kemarin</div>
                    </div>
                    <div class="stat-value"><?= $bandwidthSummary['total_bytes_formatted'] ?></div>
                    <div class="stat-label">Bandwidth Usage</div>
                </div>

                <div class="stat-card">
                    <div class="stat-card-header">
                        <div class="stat-icon interfaces">
                            <i class="fas fa-network-wired"></i>
                        </div>
                        <div class="stat-change"><?= $runningInterfaces ?> running</div>
                    </div>
                    <div class="stat-value"><?= count($interfaces) ?></div>
                    <div class="stat-label">Network Interfaces</div>
                </div>
            </div>

            <!-- Charts Section -->
            <div class="charts-grid">
                <!-- Main Chart -->
                <div class="chart-card">
                    <div class="chart-header">
                        <h4 class="chart-title"><i class="fas fa-chart-area me-2"></i>User Activity (24 Hours)</h4>
                        <select class="form-select form-select-sm" style="width: auto;">
                            <option>Last 24 Hours</option>
                            <option>Last 7 Days</option>
                            <option>Last 30 Days</option>
                        </select>
                    </div>
                    <div class="chart-container">
                        <canvas id="activityChart"></canvas>
                    </div>
                </div>

                <!-- Interface Status Chart -->
                <div class="chart-card">
                    <div class="chart-header">
                        <h4 class="chart-title"><i class="fas fa-chart-pie me-2"></i>Interface Status</h4>
                    </div>
                    <div class="chart-container small">
                        <canvas id="interfaceChart"></canvas>
                    </div>
                </div>
            </div>

            <!-- Bottom Section -->
            <div class="bottom-grid">
                <!-- Top Active Users -->
                <div class="info-card">
                    <div class="info-header">
                        <h4 class="info-title"><i class="fas fa-users me-2"></i>Top Active Users</h4>
                        <a href="hotspot.php" class="view-all">View All</a>
                    </div>
                    <div class="user-list">
                        <?php if (empty($topUsers)): ?>
                            <div class="text-center text-muted py-4">
                                <i class="fas fa-wifi fa-2x mb-2"></i>
                                <p>No active users</p>
                            </div>
                        <?php else: ?>
                            <?php foreach ($topUsers as $user): ?>
                                <div class="user-item">
                                    <div class="user-avatar">
                                        <?= strtoupper(substr($user['user'], 0, 2)) ?>
                                    </div>
                                    <div class="user-info">
                                        <div class="user-name"><?= htmlspecialchars($user['user']) ?></div>
                                        <div class="user-details"><?= $user['address'] ?> • <?= $user['uptime'] ?></div>
                                    </div>
                                    <div class="user-stats">
                                        <div class="user-usage"><?= $user['total_bytes_formatted'] ?></div>
                                        <div class="user-time"><?= $user['avg_speed_in'] ?></div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- System Status -->
                <div class="info-card">
                    <div class="info-header">
                        <h4 class="info-title"><i class="fas fa-server me-2"></i>System Status</h4>
                    </div>
                    <div class="system-info">
                        <div class="system-item">
                            <div class="system-icon">
                                <i class="fas fa-server"></i>
                            </div>
                            <div class="system-details">
                                <div class="system-label">MikroTik Router</div>
                                <div class="system-value"><?= MT_HOST ?></div>
                            </div>
                            <span class="status-badge status-online">Online</span>
                        </div>

                        <div class="system-item">
                            <div class="system-icon">
                                <i class="fas fa-database"></i>
                            </div>
                            <div class="system-details">
                                <div class="system-label">Database</div>
                                <div class="system-value">MySQL Connection</div>
                            </div>
                            <span class="status-badge status-online">Connected</span>
                        </div>

                        <div class="system-item">
                            <div class="system-icon">
                                <i class="fas fa-clock"></i>
                            </div>
                            <div class="system-details">
                                <div class="system-label">Last Sync</div>
                                <div class="system-value" id="lastSync"><?= date('H:i:s') ?></div>
                            </div>
                            <span class="status-badge status-online">Active</span>
                        </div>

                        <div class="system-item">
                            <div class="system-icon">
                                <i class="fas fa-user-shield"></i>
                            </div>
                            <div class="system-details">
                                <div class="system-label">Your Access</div>
                                <div class="system-value"><?= ucfirst($role) ?> Level</div>
                            </div>
                            <span class="status-badge status-online">Authorized</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Chart Colors
        const colors = {
            primary: '#667eea',
            secondary: '#764ba2',
            success: '#10b981',
            warning: '#f59e0b',
            danger: '#ef4444',
            info: '#06b6d4'
        };

        // Activity Chart
        const activityCtx = document.getElementById('activityChart').getContext('2d');
        const activityChart = new Chart(activityCtx, {
            type: 'line',
            data: {
                labels: <?= json_encode($hourlyData['labels']) ?>,
                datasets: [{
                    label: 'Active Users',
                    data: <?= json_encode($hourlyData['users']) ?>,
                    borderColor: colors.primary,
                    backgroundColor: colors.primary + '20',
                    fill: true,
                    tension: 0.4,
                    borderWidth: 3,
                    pointBackgroundColor: colors.primary,
                    pointBorderColor: '#fff',
                    pointBorderWidth: 2,
                    pointRadius: 4
                }, {
                    label: 'Bandwidth (MB)',
                    data: <?= json_encode($hourlyData['bandwidth']) ?>,
                    borderColor: colors.info,
                    backgroundColor: colors.info + '20',
                    fill: true,
                    tension: 0.4,
                    borderWidth: 3,
                    pointBackgroundColor: colors.info,
                    pointBorderColor: '#fff',
                    pointBorderWidth: 2,
                    pointRadius: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top',
                        labels: {
                            usePointStyle: true,
                            padding: 20
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: '#f1f5f9'
                        },
                        ticks: {
                            color: '#64748b'
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        },
                        ticks: {
                            color: '#64748b'
                        }
                    }
                },
                elements: {
                    point: {
                        hoverRadius: 8
                    }
                }
            }
        });

        // Interface Status Chart
        const interfaceCtx = document.getElementById('interfaceChart').getContext('2d');
        const interfaceChart = new Chart(interfaceCtx, {
            type: 'doughnut',
            data: {
                labels: ['Running', 'Stopped'],
                datasets: [{
                    data: <?= json_encode($interfaceStats) ?>,
                    backgroundColor: [colors.success, colors.danger],
                    borderWidth: 0,
                    cutout: '70%'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            usePointStyle: true,
                            padding: 20
                        }
                    }
                }
            }
        });

        // Update last sync time
        setInterval(() => {
            document.getElementById('lastSync').textContent = new Date().toLocaleTimeString();
        }, 1000);
    </script>
</body>
</html>