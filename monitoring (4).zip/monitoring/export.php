<?php
session_start();
require_once("config.php");
require_once("functions.php");

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Handle export request
if (isset($_GET['action']) && isset($_GET['type'])) {
    $action = $_GET['action'];
    $type = $_GET['type'];
    
    switch ($type) {
        case 'active_users':
            $data = getDetailedActiveHotspotUsers();
            $filename = "active-users-" . date('Y-m-d');
            break;
        case 'all_users':
            $data = getHotspotUserList();
            $filename = "all-users-" . date('Y-m-d');
            break;
        case 'interfaces':
            $data = getInterfaces();
            $filename = "interfaces-" . date('Y-m-d');
            break;
        default:
            die("Invalid type");
    }
    
    if ($action == 'csv') {
        exportCSV($data, $filename);
    } elseif ($action == 'excel') {
        exportExcel($data, $filename);
    }
}

function exportCSV($data, $filename) {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="' . $filename . '.csv"');
    
    $output = fopen('php://output', 'w');
    
    if (!empty($data)) {
        // Header
        fputcsv($output, array_keys($data[0]));
        // Data
        foreach ($data as $row) {
            fputcsv($output, $row);
        }
    }
    
    fclose($output);
    exit();
}

function exportExcel($data, $filename) {
    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment; filename="' . $filename . '.xls"');
    
    echo '<table border="1">';
    if (!empty($data)) {
        // Header
        echo '<tr>';
        foreach (array_keys($data[0]) as $header) {
            echo '<th>' . htmlspecialchars($header) . '</th>';
        }
        echo '</tr>';
        
        // Data
        foreach ($data as $row) {
            echo '<tr>';
            foreach ($row as $cell) {
                echo '<td>' . htmlspecialchars($cell) . '</td>';
            }
            echo '</tr>';
        }
    }
    echo '</table>';
    exit();
}

$username = $_SESSION['username'];
$role = $_SESSION['role'];

// Get data untuk preview
$activeUsers = getDetailedActiveHotspotUsers();
$allUsers = getHotspotUserList();
$interfaces = getInterfaces();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Export Data - Dashboard MikroTik</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="sidebar.css">
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background: #f8fafc;
        }
        .content-wrapper {
            padding: 20px;
            max-width: 1000px;
            margin: 0 auto;
        }
        .export-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            overflow: hidden;
        }
        .export-header {
            background: #f8fafc;
            padding: 20px;
            border-bottom: 1px solid #e2e8f0;
        }
        .export-header h4 {
            margin: 0;
            color: #1e293b;
            font-weight: 600;
        }
        .export-content {
            padding: 20px;
        }
        .export-buttons {
            display: flex;
            gap: 10px;
            margin-bottom: 15px;
        }
        .btn-export {
            padding: 8px 16px;
            border: none;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 500;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            transition: all 0.2s;
        }
        .btn-csv {
            background: #10b981;
            color: white;
        }
        .btn-csv:hover {
            background: #059669;
            color: white;
        }
        .btn-excel {
            background: #3b82f6;
            color: white;
        }
        .btn-excel:hover {
            background: #2563eb;
            color: white;
        }
        .data-preview {
            background: #f8fafc;
            border-radius: 6px;
            padding: 15px;
            font-size: 14px;
            color: #64748b;
        }
        .stats {
            display: flex;
            gap: 20px;
            margin-bottom: 15px;
        }
        .stat-item {
            background: #f1f5f9;
            padding: 10px 15px;
            border-radius: 6px;
            text-align: center;
        }
        .stat-number {
            font-size: 20px;
            font-weight: 600;
            color: #1e293b;
        }
        .stat-label {
            font-size: 12px;
            color: #64748b;
        }
    </style>
</head>

<body>
    <div class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <h3><i class="fas fa-tachometer-alt me-2"></i>DASHBOARD</h3>
        </div>
        <ul class="sidebar-nav">
            <li><a href="index.php"><span class="icon"><i class="fas fa-tachometer-alt"></i></span>Dashboard</a></li>
            <li><a href="interface.php"><span class="icon"><i class="fas fa-network-wired"></i></span>Network Interface</a></li>
            <li><a href="hotspot.php"><span class="icon"><i class="fas fa-wifi"></i></span>Hotspot Monitor</a></li>
            <li><a href="register_user.php"><span class="icon"><i class="fas fa-user-plus"></i></span>Tambah User</a></li>
            <li><a href="manage_users.php"><span class="icon"><i class="fas fa-users-cog"></i></span>Kelola User</a></li>
            <li><a href="export.php" class="active"><span class="icon"><i class="fas fa-download"></i></span>Export Data</a></li>
            <li><a href="logout.php"><span class="icon"><i class="fas fa-sign-out-alt"></i></span>Logout</a></li>
        </ul>
    </div>

    <div class="main-content">
        <div class="content-wrapper">
            <div class="mb-4">
                <h1><i class="fas fa-download me-2"></i>Export Data</h1>
                <p class="text-muted">Export data MikroTik dalam format CSV atau Excel</p>
            </div>

            <!-- Active Users Export -->
            <div class="export-card">
                <div class="export-header">
                    <h4><i class="fas fa-users me-2"></i>Active Users</h4>
                </div>
                <div class="export-content">
                    <div class="stats">
                        <div class="stat-item">
                            <div class="stat-number"><?= count($activeUsers) ?></div>
                            <div class="stat-label">Users Online</div>
                        </div>
                    </div>
                    <div class="export-buttons">
                        <a href="export.php?action=csv&type=active_users" class="btn-export btn-csv">
                            <i class="fas fa-file-csv"></i>Download CSV
                        </a>
                        <a href="export.php?action=excel&type=active_users" class="btn-export btn-excel">
                            <i class="fas fa-file-excel"></i>Download Excel
                        </a>
                    </div>
                    <div class="data-preview">
                        <strong>Data yang akan di-export:</strong><br>
                        Username, IP Address, MAC Address, Login Time, Uptime, Bytes In, Bytes Out, Total Usage
                    </div>
                </div>
            </div>

            <!-- All Users Export -->
            <div class="export-card">
                <div class="export-header">
                    <h4><i class="fas fa-user-friends me-2"></i>All Users</h4>
                </div>
                <div class="export-content">
                    <div class="stats">
                        <div class="stat-item">
                            <div class="stat-number"><?= count($allUsers) ?></div>
                            <div class="stat-label">Total Users</div>
                        </div>
                    </div>
                    <div class="export-buttons">
                        <a href="export.php?action=csv&type=all_users" class="btn-export btn-csv">
                            <i class="fas fa-file-csv"></i>Download CSV
                        </a>
                        <a href="export.php?action=excel&type=all_users" class="btn-export btn-excel">
                            <i class="fas fa-file-excel"></i>Download Excel
                        </a>
                    </div>
                    <div class="data-preview">
                        <strong>Data yang akan di-export:</strong><br>
                        Username, Password, Profile, Server, Comment, Disabled Status
                    </div>
                </div>
            </div>

            <!-- Interfaces Export -->
            <div class="export-card">
                <div class="export-header">
                    <h4><i class="fas fa-network-wired me-2"></i>Network Interfaces</h4>
                </div>
                <div class="export-content">
                    <div class="stats">
                        <div class="stat-item">
                            <div class="stat-number"><?= count($interfaces) ?></div>
                            <div class="stat-label">Interfaces</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-number"><?= count(array_filter($interfaces, function($i) { return $i['running'] == 'true'; })) ?></div>
                            <div class="stat-label">Running</div>
                        </div>
                    </div>
                    <div class="export-buttons">
                        <a href="export.php?action=csv&type=interfaces" class="btn-export btn-csv">
                            <i class="fas fa-file-csv"></i>Download CSV
                        </a>
                        <a href="export.php?action=excel&type=interfaces" class="btn-export btn-excel">
                            <i class="fas fa-file-excel"></i>Download Excel
                        </a>
                    </div>
                    <div class="data-preview">
                        <strong>Data yang akan di-export:</strong><br>
                        Interface Name, Type, Running Status, Disabled Status, MTU, MAC Address
                    </div>
                </div>
            </div>

            <!-- Quick Export All -->
            <div class="export-card">
                <div class="export-header">
                    <h4><i class="fas fa-download me-2"></i>Quick Export All</h4>
                </div>
                <div class="export-content">
                    <p class="text-muted mb-3">Download semua data sekaligus dalam satu file</p>
                    <div class="export-buttons">
                        <a href="export_all.php?format=csv" class="btn-export btn-csv">
                            <i class="fas fa-file-csv"></i>All Data CSV
                        </a>
                        <a href="export_all.php?format=excel" class="btn-export btn-excel">
                            <i class="fas fa-file-excel"></i>All Data Excel
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>