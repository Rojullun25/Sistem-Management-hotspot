<?php
require_once("routeros_api.class.php");
require_once("config.php");

$API = new RouterosAPI();

function getInterfaces() {
    $API = new RouterosAPI();
    if ($API->connect(MT_HOST, MT_USER, MT_PASS)) {
        $interfaces = $API->comm("/interface/print");
        $API->disconnect();
        return $interfaces;
    } else {
        return [];
    }
}

function logBandwidthToDB($mysqli) {
    $API = new RouterosAPI();
    if ($API->connect(MT_HOST, MT_USER, MT_PASS)) {
        $interfaces = $API->comm("/interface/print");
        foreach ($interfaces as $iface) {
            $name = trim($iface['name']);
            $rx = isset($iface['rx-byte']) ? $iface['rx-byte'] : 0;
            $tx = isset($iface['tx-byte']) ? $iface['tx-byte'] : 0;

            // Ambil ID dari tabel interfaces
            $stmt = $mysqli->prepare("SELECT id FROM interfaces WHERE interface_name = ? LIMIT 1");
            $stmt->bind_param("s", $name);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($row = $result->fetch_assoc()) {
                $interface_id = $row['id'];

                $stmt2 = $mysqli->prepare("INSERT INTO bandwidth_logs (interface_id, rx, tx) VALUES (?, ?, ?)");
                $stmt2->bind_param("iii", $interface_id, $rx, $tx);
                $stmt2->execute();

                if ($stmt2->affected_rows > 0) {
                    echo "✅ Log bandwidth berhasil ditambahkan untuk interface: $name (ID: $interface_id)<br>";
                } else {
                    echo "⚠️  Gagal menambahkan log untuk interface: $name (ID: $interface_id)<br>";
                }

                $stmt2->close();
            } else {
                echo "❌ Interface '$name' tidak ditemukan di tabel interfaces. Lewati insert.<br>";
            }

            $stmt->close();
        }
        $API->disconnect();
    } else {
        echo "❌ Gagal koneksi ke MikroTik pada logBandwidthToDB()<br>";
    }
}

// Function untuk mendapatkan daftar user hotspot aktif
function getActiveHotspotUsers() {
    $API = new RouterosAPI();
    if ($API->connect(MT_HOST, MT_USER, MT_PASS)) {
        $users = $API->comm("/ip/hotspot/active/print");
        $API->disconnect();
        return $users;
    }
    return [];
}

// Function untuk mendapatkan semua user hotspot
function getHotspotUserList() {
    $API = new RouterosAPI();
    if ($API->connect(MT_HOST, MT_USER, MT_PASS)) {
        $data = $API->comm("/ip/hotspot/user/print");
        $API->disconnect();
        return $data;
    }
    return [];
}

// Function untuk mendapatkan daftar hotspot aktif (alias untuk getActiveHotspotUsers)
function getHotspotActiveList() {
    return getActiveHotspotUsers();
}

// Function untuk mendapatkan interface wireless
function getWirelessInterfaceList() {
    $API = new RouterosAPI();
    if ($API->connect(MT_HOST, MT_USER, MT_PASS)) {
        $data = $API->comm("/interface/wireless/print");
        $API->disconnect();
        return $data;
    }
    return [];
}

// Function baru untuk mendapatkan statistik hotspot yang lebih detail
function getHotspotStatistics() {
    $activeUsers = getActiveHotspotUsers();
    $allUsers = getHotspotUserList();
    
    $stats = [
        'total_users' => count($allUsers),
        'active_users' => count($activeUsers),
        'inactive_users' => count($allUsers) - count($activeUsers),
        'active_list' => $activeUsers,
        'all_users' => $allUsers
    ];
    
    return $stats;
}

// Function untuk mendapatkan detail user hotspot aktif dengan informasi lengkap
function getDetailedActiveHotspotUsers() {
    $API = new RouterosAPI();
    if ($API->connect(MT_HOST, MT_USER, MT_PASS)) {
        $activeUsers = $API->comm("/ip/hotspot/active/print");
        $detailedUsers = [];
        
        foreach ($activeUsers as $user) {
            $detailedUser = [
                'id' => $user['.id'] ?? '',
                'user' => $user['user'] ?? 'Unknown',
                'address' => $user['address'] ?? '0.0.0.0',
                'mac_address' => $user['mac-address'] ?? 'Unknown',
                'login_time' => $user['login-time'] ?? '00:00:00',
                'uptime' => $user['uptime'] ?? '00:00:00',
                'session_time_left' => $user['session-time-left'] ?? 'Unlimited',
                'idle_time' => $user['idle-time'] ?? '00:00:00',
                'idle_timeout' => $user['idle-timeout'] ?? 'None',
                'ping_timeout' => $user['ping-timeout'] ?? 'None',
                'bytes_in' => $user['bytes-in'] ?? 0,
                'bytes_out' => $user['bytes-out'] ?? 0,
                'packets_in' => $user['packets-in'] ?? 0,
                'packets_out' => $user['packets-out'] ?? 0,
                'limit_bytes_in' => $user['limit-bytes-in'] ?? 0,
                'limit_bytes_out' => $user['limit-bytes-out'] ?? 0,
                'server' => $user['server'] ?? 'hotspot1',
                'radius' => $user['radius'] ?? false,
                'blocked' => $user['blocked'] ?? false
            ];
            
            // Format bytes ke format yang lebih readable
            $detailedUser['bytes_in_formatted'] = formatBytes($detailedUser['bytes_in']);
            $detailedUser['bytes_out_formatted'] = formatBytes($detailedUser['bytes_out']);
            $detailedUser['total_bytes_formatted'] = formatBytes($detailedUser['bytes_in'] + $detailedUser['bytes_out']);
            
            // Hitung kecepatan rata-rata jika uptime tersedia
            if ($detailedUser['uptime'] !== '00:00:00') {
                $uptimeSeconds = convertUptimeToSeconds($detailedUser['uptime']);
                if ($uptimeSeconds > 0) {
                    $avgSpeedIn = $detailedUser['bytes_in'] / $uptimeSeconds;
                    $avgSpeedOut = $detailedUser['bytes_out'] / $uptimeSeconds;
                    $detailedUser['avg_speed_in'] = formatBytes($avgSpeedIn) . '/s';
                    $detailedUser['avg_speed_out'] = formatBytes($avgSpeedOut) . '/s';
                } else {
                    $detailedUser['avg_speed_in'] = '0 B/s';
                    $detailedUser['avg_speed_out'] = '0 B/s';
                }
            } else {
                $detailedUser['avg_speed_in'] = '0 B/s';
                $detailedUser['avg_speed_out'] = '0 B/s';
            }
            
            $detailedUsers[] = $detailedUser;
        }
        
        $API->disconnect();
        return $detailedUsers;
    }
    return [];
}

// Function untuk disconnect user hotspot
function disconnectHotspotUser($userId) {
    $API = new RouterosAPI();
    if ($API->connect(MT_HOST, MT_USER, MT_PASS)) {
        try {
            $result = $API->comm("/ip/hotspot/active/remove", [
                ".id" => $userId
            ]);
            $API->disconnect();
            return true;
        } catch (Exception $e) {
            $API->disconnect();
            return false;
        }
    }
    return false;
}

// Function untuk mendapatkan profil hotspot
function getHotspotProfiles() {
    $API = new RouterosAPI();
    if ($API->connect(MT_HOST, MT_USER, MT_PASS)) {
        $profiles = $API->comm("/ip/hotspot/user/profile/print");
        $API->disconnect();
        return $profiles;
    }
    return [];
}

// Function untuk mendapatkan server hotspot
function getHotspotServers() {
    $API = new RouterosAPI();
    if ($API->connect(MT_HOST, MT_USER, MT_PASS)) {
        $servers = $API->comm("/ip/hotspot/print");
        $API->disconnect();
        return $servers;
    }
    return [];
}

// Helper function untuk format bytes
function formatBytes($bytes, $precision = 2) {
    $units = array('B', 'KB', 'MB', 'GB', 'TB');
    
    for ($i = 0; $bytes > 1024 && $i < count($units) - 1; $i++) {
        $bytes /= 1024;
    }
    
    return round($bytes, $precision) . ' ' . $units[$i];
}

// Helper function untuk convert uptime ke seconds
function convertUptimeToSeconds($uptime) {
    if (empty($uptime) || $uptime === '00:00:00') {
        return 0;
    }
    
    // Format bisa berupa: 1d2h3m4s atau 2h3m4s atau 3m4s atau 4s
    $seconds = 0;
    
    // Parse days
    if (preg_match('/(\d+)d/', $uptime, $matches)) {
        $seconds += $matches[1] * 86400;
    }
    
    // Parse hours
    if (preg_match('/(\d+)h/', $uptime, $matches)) {
        $seconds += $matches[1] * 3600;
    }
    
    // Parse minutes
    if (preg_match('/(\d+)m/', $uptime, $matches)) {
        $seconds += $matches[1] * 60;
    }
    
    // Parse seconds
    if (preg_match('/(\d+)s/', $uptime, $matches)) {
        $seconds += $matches[1];
    }
    
    // Jika format HH:MM:SS
    if (preg_match('/(\d+):(\d+):(\d+)/', $uptime, $matches)) {
        $seconds = $matches[1] * 3600 + $matches[2] * 60 + $matches[3];
    }
    
    return $seconds;
}

// Function untuk mendapatkan ringkasan bandwidth hotspot
function getHotspotBandwidthSummary() {
    $activeUsers = getDetailedActiveHotspotUsers();
    
    $totalBytesIn = 0;
    $totalBytesOut = 0;
    $totalUsers = count($activeUsers);
    
    foreach ($activeUsers as $user) {
        $totalBytesIn += $user['bytes_in'];
        $totalBytesOut += $user['bytes_out'];
    }
    
    return [
        'total_users' => $totalUsers,
        'total_bytes_in' => $totalBytesIn,
        'total_bytes_out' => $totalBytesOut,
        'total_bytes' => $totalBytesIn + $totalBytesOut,
        'total_bytes_in_formatted' => formatBytes($totalBytesIn),
        'total_bytes_out_formatted' => formatBytes($totalBytesOut),
        'total_bytes_formatted' => formatBytes($totalBytesIn + $totalBytesOut),
        'avg_bytes_per_user' => $totalUsers > 0 ? formatBytes(($totalBytesIn + $totalBytesOut) / $totalUsers) : '0 B'
    ];
}

// Function untuk monitoring real-time hotspot
function getHotspotRealTimeData() {
    return [
        'timestamp' => date('Y-m-d H:i:s'),
        'active_users' => getDetailedActiveHotspotUsers(),
        'statistics' => getHotspotStatistics(),
        'bandwidth_summary' => getHotspotBandwidthSummary(),
        'servers' => getHotspotServers(),
        'profiles' => getHotspotProfiles()
    ];
}

?>