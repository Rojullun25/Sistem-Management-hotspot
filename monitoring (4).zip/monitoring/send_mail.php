<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

function kirimEmail($tujuan, $subject, $isiPesan) {
    $mail = new PHPMailer(true);

    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'creatorsunda022@gmail.com';
        $mail->Password   = 'meqextjdkzldouqg';  // App Password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;

        // Pengirim & Penerima
        $mail->setFrom('creatorsunda022@gmail.com', 'System');
        $mail->addAddress($tujuan);

        // Isi Email
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = $isiPesan;
        $mail->AltBody = strip_tags($isiPesan);

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("Gagal kirim email: {$mail->ErrorInfo}");
        return false;
    }
}
