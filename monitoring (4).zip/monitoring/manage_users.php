<?php
session_start();
require_once("config.php");

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    die("❌ Akses ditolak. Halaman ini hanya untuk admin.");
}

$result = $mysqli->query("SELECT id, username, role, created_at FROM users ORDER BY id ASC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Kelola User - MikroTik Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="sidebar.css">
    <link rel="stylesheet" href="manage-users-style.css">
</head>
<body>
    <div class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <h3><i class="fas fa-tachometer-alt me-2"></i>DASHBOARD</h3>
        </div>
        <ul class="sidebar-nav">
            <li><a href="index.php"><span class="icon"><i class="fas fa-tachometer-alt"></i></span>Dashboard</a></li>
            <li><a href="interface.php"><span class="icon"><i class="fas fa-network-wired"></i></span>Network Interface</a></li>
            <li><a href="hotspot.php"><span class="icon"><i class="fas fa-wifi"></i></span>Hotspot Monitor</a></li>
            <li><a href="register_user.php"><span class="icon"><i class="fas fa-user-plus"></i></span>Tambah User</a></li>
            <li><a href="manage_users.php"><span class="icon"><i class="fas fa-users-cog"></i></span>Kelola User</a></li>
            <li><a href="export.php" class="active"><span class="icon"><i class="fas fa-download"></i></span>Export Data</a></li>
            <li><a href="logout.php"><span class="icon"><i class="fas fa-sign-out-alt"></i></span>Logout</a></li>
        </ul>
    </div>

    <div class="main-content">
        <div class="content-wrapper">
            <!-- Page Header -->
            <div class="page-header">
                <div class="header-content">
                    <div class="header-icon">
                        <i class="fas fa-users-cog"></i>
                    </div>
                    <div class="header-text">
                        <h1>Kelola Pengguna</h1>
                        <p>Manage dan monitor semua user yang terdaftar dalam sistem</p>
                    </div>
                </div>
                <div class="header-actions">
                    <a href="register_user.php" class="btn btn-primary">
                        <i class="fas fa-user-plus me-2"></i>Tambah User Baru
                    </a>
                </div>
            </div>

            <!-- Stats Cards -->
            <div class="stats-grid">
                <div class="stat-card total-users">
                    <div class="stat-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="stat-content">
                        <h3><?= $result->num_rows ?></h3>
                        <p>Total Users</p>
                        <div class="stat-trend">
                            <i class="fas fa-database"></i>
                            <span>Terdaftar</span>
                        </div>
                    </div>
                </div>

                <div class="stat-card admin-users">
                    <div class="stat-icon">
                        <i class="fas fa-user-shield"></i>
                    </div>
                    <div class="stat-content">
                        <h3><?php 
                            $admin_count = $mysqli->query("SELECT COUNT(*) as count FROM users WHERE role = 'admin'")->fetch_assoc()['count'];
                            echo $admin_count;
                        ?></h3>
                        <p>Admin Users</p>
                        <div class="stat-trend">
                            <i class="fas fa-crown"></i>
                            <span>Administrator</span>
                        </div>
                    </div>
                </div>

                <div class="stat-card teknisi-users">
                    <div class="stat-icon">
                        <i class="fas fa-user-cog"></i>
                    </div>
                    <div class="stat-content">
                        <h3><?php 
                            $teknisi_count = $mysqli->query("SELECT COUNT(*) as count FROM users WHERE role = 'teknisi'")->fetch_assoc()['count'];
                            echo $teknisi_count;
                        ?></h3>
                        <p>Teknisi Users</p>
                        <div class="stat-trend">
                            <i class="fas fa-tools"></i>
                            <span>Technical</span>
                        </div>
                    </div>
                </div>

                <div class="stat-card operator-users">
                    <div class="stat-icon">
                        <i class="fas fa-user"></i>
                    </div>
                    <div class="stat-content">
                        <h3><?php 
                            $operator_count = $mysqli->query("SELECT COUNT(*) as count FROM users WHERE role = 'operator'")->fetch_assoc()['count'];
                            echo $operator_count;
                        ?></h3>
                        <p>Operator Users</p>
                        <div class="stat-trend">
                            <i class="fas fa-headset"></i>
                            <span>Support</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Users Table -->
            <div class="data-card">
                <div class="card-header">
                    <div class="header-left">
                        <h3><i class="fas fa-table me-2"></i>Daftar Pengguna</h3>
                        <span class="user-count"><?= $result->num_rows ?> users terdaftar</span>
                    </div>
                    <div class="header-right">
                        <div class="search-box">
                            <input type="text" id="searchUser" placeholder="Cari username atau role..." onkeyup="searchUsers()">
                            <i class="fas fa-search"></i>
                        </div>
                        <div class="filter-dropdown">
                            <select id="roleFilter" onchange="filterByRole()">
                                <option value="">Semua Role</option>
                                <option value="admin">Admin</option>
                                <option value="teknisi">Teknisi</option>
                                <option value="operator">Operator</option>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="table-container">
                    <table class="users-table" id="usersTable">
                        <thead>
                            <tr>
                                <th><i class="fas fa-hashtag"></i></th>
                                <th><i class="fas fa-user me-1"></i>Username</th>
                                <th><i class="fas fa-user-tag me-1"></i>Role</th>
                                <th><i class="fas fa-calendar me-1"></i>Dibuat</th>
                                <th><i class="fas fa-circle me-1"></i>Status</th>
                                <th><i class="fas fa-cogs me-1"></i>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $result->data_seek(0); // Reset pointer
                            $index = 1;
                            while ($row = $result->fetch_assoc()): 
                            ?>
                                <tr class="user-row" data-role="<?= $row['role'] ?>">
                                    <td class="row-number"><?= $index++ ?></td>
                                    <td class="username">
                                        <div class="user-info">
                                            <div class="user-avatar <?= $row['role'] ?>">
                                                <?php if ($row['role'] === 'admin'): ?>
                                                    <i class="fas fa-user-shield"></i>
                                                <?php elseif ($row['role'] === 'teknisi'): ?>
                                                    <i class="fas fa-user-cog"></i>
                                                <?php else: ?>
                                                    <i class="fas fa-user"></i>
                                                <?php endif; ?>
                                            </div>
                                            <div class="user-details">
                                                <strong><?= htmlspecialchars($row['username']) ?></strong>
                                                <small>ID: <?= $row['id'] ?></small>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="role">
                                        <span class="role-badge <?= $row['role'] ?>">
                                            <?php if ($row['role'] === 'admin'): ?>
                                                <i class="fas fa-crown me-1"></i>Administrator
                                            <?php elseif ($row['role'] === 'teknisi'): ?>
                                                <i class="fas fa-tools me-1"></i>Teknisi
                                            <?php else: ?>
                                                <i class="fas fa-headset me-1"></i>Operator
                                            <?php endif; ?>
                                        </span>
                                    </td>
                                    <td class="created-date">
                                        <div class="date-info">
                                            <span class="date"><?= isset($row['created_at']) ? date('d/m/Y', strtotime($row['created_at'])) : 'N/A' ?></span>
                                            <small class="time"><?= isset($row['created_at']) ? date('H:i', strtotime($row['created_at'])) : '' ?></small>
                                        </div>
                                    </td>
                                    <td class="status">
                                        <span class="status-badge active">
                                            <i class="fas fa-circle"></i>
                                            Active
                                        </span>
                                    </td>
                                    <td class="actions">
                                        <div class="action-buttons">
                                            <button class="btn-action btn-info" title="View Details" onclick="viewUserDetails(<?= $row['id'] ?>, '<?= htmlspecialchars($row['username']) ?>')">
                                                <i class="fas fa-eye"></i>
                                            </button>
                                            <a href="edit_users.php?id=<?= $row['id'] ?>" class="btn-action btn-warning" title="Edit User">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <?php if ($row['username'] !== $_SESSION['username']): ?>
                                                <button class="btn-action btn-danger" title="Delete User" 
                                                        onclick="confirmDelete('<?= htmlspecialchars($row['username']) ?>', <?= $row['id'] ?>)">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            <?php else: ?>
                                                <button class="btn-action btn-secondary" title="Cannot delete yourself" disabled>
                                                    <i class="fas fa-ban"></i>
                                                </button>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Quick Actions -->
            <div class="quick-actions">
                <div class="action-card">
                    <div class="action-icon">
                        <i class="fas fa-user-plus"></i>
                    </div>
                    <div class="action-content">
                        <h4>Tambah User Baru</h4>
                        <p>Buat akun pengguna baru untuk sistem</p>
                        <a href="register_user.php" class="btn btn-outline-primary">
                            <i class="fas fa-plus me-2"></i>Tambah User
                        </a>
                    </div>
                </div>

                <div class="action-card">
                    <div class="action-icon">
                        <i class="fas fa-download"></i>
                    </div>
                    <div class="action-content">
                        <h4>Export Data</h4>
                        <p>Download daftar user dalam format CSV</p>
                        <button class="btn btn-outline-success" onclick="exportUsers()">
                            <i class="fas fa-file-csv me-2"></i>Export CSV
                        </button>
                    </div>
                </div>

                <div class="action-card">
                    <div class="action-icon">
                        <i class="fas fa-shield-alt"></i>
                    </div>
                    <div class="action-content">
                        <h4>Security Log</h4>
                        <p>Lihat log aktivitas dan keamanan</p>
                        <button class="btn btn-outline-info" onclick="viewSecurityLog()">
                            <i class="fas fa-history me-2"></i>View Log
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- User Details Modal -->
    <div id="userDetailsModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-user-circle me-2"></i>Detail User</h3>
                <span class="close" onclick="closeModal()">&times;</span>
            </div>
            <div class="modal-body" id="userDetailsContent">
                <!-- Content will be loaded here -->
            </div>
        </div>
    </div>

    <!-- Delete Confirmation Modal -->
    <div id="deleteModal" class="modal">
        <div class="modal-content delete-modal">
            <div class="modal-header">
                <h3><i class="fas fa-exclamation-triangle me-2"></i>Konfirmasi Hapus</h3>
                <span class="close" onclick="closeDeleteModal()">&times;</span>
            </div>
            <div class="modal-body">
                <div class="delete-warning">
                    <i class="fas fa-trash-alt"></i>
                    <h4>Yakin ingin menghapus user ini?</h4>
                    <p>User <strong id="deleteUsername"></strong> akan dihapus dari database dan MikroTik. Tindakan ini tidak dapat dibatalkan.</p>
                </div>
                <div class="delete-actions">
                    <button class="btn btn-secondary" onclick="closeDeleteModal()">
                        <i class="fas fa-times me-2"></i>Batal
                    </button>
                    <a id="deleteConfirmBtn" href="#" class="btn btn-danger">
                        <i class="fas fa-trash me-2"></i>Hapus User
                    </a>
                </div>
            </div>
        </div>
    </div>

    <script>
        function toggleSidebar() {
            document.getElementById('sidebar').classList.toggle('active');
        }

        function searchUsers() {
            const input = document.getElementById('searchUser');
            const filter = input.value.toLowerCase();
            const table = document.getElementById('usersTable');
            const rows = table.getElementsByTagName('tr');
            
            for (let i = 1; i < rows.length; i++) {
                const row = rows[i];
                const username = row.querySelector('.username');
                const role = row.querySelector('.role');
                
                if (username && role) {
                    const usernameText = username.textContent.toLowerCase();
                    const roleText = role.textContent.toLowerCase();
                    
                    if (usernameText.includes(filter) || roleText.includes(filter)) {
                        row.style.display = '';
                    } else {
                        row.style.display = 'none';
                    }
                }
            }
        }

        function filterByRole() {
            const filter = document.getElementById('roleFilter').value;
            const rows = document.querySelectorAll('.user-row');
            
            rows.forEach(row => {
                if (filter === '' || row.dataset.role === filter) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        }

        function viewUserDetails(userId, username) {
            document.getElementById('userDetailsModal').style.display = 'block';
            document.getElementById('userDetailsContent').innerHTML = `
                <div class="user-detail-info">
                    <div class="detail-header">
                        <div class="detail-avatar">
                            <i class="fas fa-user-circle"></i>
                        </div>
                        <div class="detail-info">
                            <h4>${username}</h4>
                            <p>User ID: ${userId}</p>
                        </div>
                    </div>
                    <div class="detail-content">
                        <div class="detail-item">
                            <strong>Status:</strong>
                            <span class="status-badge active">
                                <i class="fas fa-circle"></i> Active
                            </span>
                        </div>
                        <div class="detail-item">
                            <strong>Last Login:</strong>
                            <span>Today, 10:30 AM</span>
                        </div>
                        <div class="detail-item">
                            <strong>Permissions:</strong>
                            <span>Full Access</span>
                        </div>
                    </div>
                </div>
            `;
        }

        function confirmDelete(username, userId) {
            document.getElementById('deleteUsername').textContent = username;
            document.getElementById('deleteConfirmBtn').href = `delete_user.php?username=${encodeURIComponent(username)}`;
            document.getElementById('deleteModal').style.display = 'block';
        }

        function closeModal() {
            document.getElementById('userDetailsModal').style.display = 'none';
        }

        function closeDeleteModal() {
            document.getElementById('deleteModal').style.display = 'none';
        }

        function exportUsers() {
            // Simulate export functionality
            alert('Export functionality akan segera tersedia!');
        }

        function viewSecurityLog() {
            // Simulate security log functionality
            alert('Security log functionality akan segera tersedia!');
        }

        // Close modals when clicking outside
        window.onclick = function(event) {
            const userModal = document.getElementById('userDetailsModal');
            const deleteModal = document.getElementById('deleteModal');
            
            if (event.target == userModal) {
                userModal.style.display = 'none';
            }
            if (event.target == deleteModal) {
                deleteModal.style.display = 'none';
            }
        }
    </script>
</body>
</html>