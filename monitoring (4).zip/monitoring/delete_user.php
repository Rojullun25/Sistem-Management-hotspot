<?php
session_start();
require_once("config.php");
require_once("routeros_api.class.php");

// ✅ Cek autentikasi dan role
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    die("❌ Akses ditolak.");
}

// ✅ Validasi parameter
if (!isset($_GET['username']) || trim($_GET['username']) === '') {
    die("❌ Username tidak valid.");
}

$username = trim($_GET['username']);
$db_deleted = false;
$mt_deleted = false;

// ✅ Hapus dari database
$stmt = $mysqli->prepare("DELETE FROM users WHERE username = ?");
if ($stmt) {
    $stmt->bind_param("s", $username);
    $db_deleted = $stmt->execute();
    $stmt->close();
}

// ✅ Hapus dari MikroTik
$API = new RouterosAPI();
if ($API->connect(MT_HOST, MT_USER, MT_PASS)) {
    $users = $API->comm("/ip/hotspot/user/print", ["?name" => $username]);
    if (!empty($users)) {
        $user_id = $users[0][".id"];
        $API->comm("/ip/hotspot/user/remove", ["numbers" => $user_id]);
        $mt_deleted = true;
    }
    $API->disconnect();
}

// ✅ Redirect dengan feedback
$redirect = "Location: manage_users.php?msg=";
if ($db_deleted && $mt_deleted) {
    header($redirect . urlencode("✅ User berhasil dihapus dari DB & MikroTik"));
} elseif ($db_deleted) {
    header($redirect . urlencode("ℹ️ User hanya dihapus dari DB (tidak ditemukan di MikroTik)"));
} else {
    header($redirect . urlencode("❌ Gagal menghapus user"));
}
exit();
