<?php
session_start();
require_once("config.php");
require_once("functions.php");

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$role = $_SESSION['role'];
$username = $_SESSION['username'];
$interfaces = getInterfaces();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Network Interface - MikroTik Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&family=Inter:wght@400;500;600;700;800&family=Nunito:wght@400;500;600;700;800&family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="sidebar.css">
</head>

<body>

    
    <div class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <h3><i class="fas fa-tachometer-alt me-2"></i>DASHBOARD</h3>
        </div>
        <ul class="sidebar-nav">
            <li><a href="index.php"><span class="icon"><i class="fas fa-tachometer-alt"></i></span>Dashboard</a></li>
            <li><a href="interface.php"><span class="icon"><i class="fas fa-network-wired"></i></span>Network Interface</a></li>
            <li><a href="hotspot.php"><span class="icon"><i class="fas fa-wifi"></i></span>Hotspot Monitor</a></li>
            <li><a href="register_user.php"><span class="icon"><i class="fas fa-user-plus"></i></span>Tambah User</a></li>
            <li><a href="manage_users.php"><span class="icon"><i class="fas fa-users-cog"></i></span>Kelola User</a></li>
            <li><a href="export.php" class="active"><span class="icon"><i class="fas fa-download"></i></span>Export Data</a></li>
            <li><a href="logout.php"><span class="icon"><i class="fas fa-sign-out-alt"></i></span>Logout</a></li>
        </ul>
    </div>
    
    <div class="main-content">
        <div class="content-wrapper">
            <!-- Interface Statistics -->
            <div class="row mb-4">
                <div class="col-md-4">
                    <div class="card bg-success text-white">
                        <div class="card-body">
                            <div class="d-flex align-items-center justify-content-between">
                                <div>
                                    <h3 class="mb-0"><?= count(array_filter($interfaces, function($iface) { return $iface['running'] == 'true'; })) ?></h3>
                                    <p class="mb-0">Online Interfaces</p>
                                </div>
                                <i class="fas fa-check-circle fa-2x"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card bg-danger text-white">
                        <div class="card-body">
                            <div class="d-flex align-items-center justify-content-between">
                                <div>
                                    <h3 class="mb-0"><?= count(array_filter($interfaces, function($iface) { return $iface['running'] != 'true'; })) ?></h3>
                                    <p class="mb-0">Offline Interfaces</p>
                                </div>
                                <i class="fas fa-times-circle fa-2x"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card bg-info text-white">
                        <div class="card-body">
                            <div class="d-flex align-items-center justify-content-between">
                                <div>
                                    <h3 class="mb-0"><?= count($interfaces) ?></h3>
                                    <p class="mb-0">Total Interfaces</p>
                                </div>
                                <i class="fas fa-network-wired fa-2x"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Interface Status Section -->
            <div class="section-header interface">
                <div class="d-flex align-items-center justify-content-between">
                    <div>
                        <h2 class="section-title" style="color: #28a745;">
                            <i class="fas fa-ethernet me-2"></i>
                            Status Interface MikroTik
                        </h2>
                        <p class="section-subtitle">Status dan informasi detail interface jaringan</p>
                    </div>
                    <div class="d-flex gap-2">
                        <button class="btn btn-outline-success btn-sm" onclick="refreshInterfaces()">
                            <i class="fas fa-sync-alt me-1"></i>Refresh
                        </button>
                        <span class="badge px-3 py-2" style="background: linear-gradient(135deg, #28a745 0%, #20c997 100%); font-size: 1rem; border-radius: 20px;">
                            <?= count($interfaces) ?> Interfaces
                        </span>
                    </div>
                </div>
            </div>
            
            <div class="card shadow-sm border-0 mb-5">
                <div class="card-header text-white" style="background: linear-gradient(135deg, #28a745 0%, #20c997 100%);">
                    <h5 class="mb-0 fw-bold">
                        <i class="fas fa-network-wired me-2"></i>Network Interface Status
                    </h5>
                </div>
                
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead style="background: #f8f9fa; border-bottom: 2px solid #dee2e6;">
                                <tr>
                                    <th class="text-center fw-bold" style="width: 60px; padding: 16px 8px; color: #495057; font-size: 13px; text-transform: uppercase; letter-spacing: 1px;">
                                        <span class="badge bg-secondary rounded-pill">No</span>
                                    </th>
                                    <th class="fw-bold" style="padding: 16px; color: #495057; font-size: 13px; text-transform: uppercase; letter-spacing: 1px;">
                                        <i class="fas fa-tag me-2 text-primary"></i>Interface Name
                                    </th>
                                    <th class="fw-bold" style="padding: 16px; color: #495057; font-size: 13px; text-transform: uppercase; letter-spacing: 1px;">
                                        <i class="fas fa-cogs me-2 text-info"></i>Type
                                    </th>
                                    <th class="fw-bold" style="padding: 16px; color: #495057; font-size: 13px; text-transform: uppercase; letter-spacing: 1px;">
                                        <i class="fas fa-signal me-2 text-success"></i>Status
                                    </th>
                                    
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($interfaces as $i => $iface): ?>
                                <tr class="align-middle">
                                    <td class="text-center">
                                        <span class="badge bg-secondary rounded-pill"><?= $i+1 ?></span>
                                    </td>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="avatar-sm rounded-circle d-flex align-items-center justify-content-center me-2" 
                                                 style="width: 32px; height: 32px; background: <?= ($iface['running'] == 'true') ? '#28a745' : '#dc3545' ?>;">
                                                <i class="fas fa-ethernet text-white" style="font-size: 12px;"></i>
                                            </div>
                                            <span class="fw-medium text-dark"><?= $iface['name'] ?? 'Unknown' ?></span>
                                        </div>
                                    </td>
                                    <td>
                                        <?php if (($iface['type'] ?? '-') !== '-'): ?>
                                            <span class="badge bg-info rounded-pill px-3 py-2">
                                                <i class="fas fa-microchip me-1"></i>
                                                <?= $iface['type'] ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="text-muted fst-italic">Unknown Type</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($iface['running'] == 'true'): ?>
                                            <span class="badge bg-success rounded-pill px-3 py-2">
                                                <i class="fas fa-check-circle me-1"></i>
                                                Online
                                            </span>
                                        <?php else: ?>
                                            <span class="badge bg-danger rounded-pill px-3 py-2">
                                                <i class="fas fa-times-circle me-1"></i>
                                                Offline
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach ?>
                                
                                <?php if (empty($interfaces)): ?>
                                <tr>
                                    <td colspan="6" class="text-center py-5">
                                        <div class="text-muted">
                                            <i class="fas fa-network-wired fa-3x mb-3 opacity-25"></i>
                                            <h5 class="text-muted">Tidak ada interface ditemukan</h5>
                                            <p class="mb-0">Tidak dapat mengambil data interface dari MikroTik</p>
                                        </div>
                                    </td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="card-footer bg-light text-muted text-center py-2">
                    <small>
                        <i class="fas fa-info-circle me-1"></i>
                        Total: <?= count($interfaces) ?> network interfaces | 
                        Online: <?= count(array_filter($interfaces, function($iface) { return $iface['running'] == 'true'; })) ?> | 
                        Offline: <?= count(array_filter($interfaces, function($iface) { return $iface['running'] != 'true'; })) ?> |
                        Last Updated: <?= date('H:i:s') ?>
                    </small>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        function toggleSidebar() {
            document.getElementById('sidebar').classList.toggle('active');
        }
        
        function refreshInterfaces() {
            location.reload();
        }
    </script>
</body>
</html>