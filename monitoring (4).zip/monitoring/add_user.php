<?php
require_once("config.php");
require_once("send_mail.php"); // Tambahkan ini agar bisa kirim email

$username = 'admin';
$password = password_hash('admin123', PASSWORD_BCRYPT);
$role = 'admin';

// ✅ Tambahkan email jika kamu ingin dinamis
$email = 'admin@gmail.com'; // Ganti ke alamat email admin

$stmt = $mysqli->prepare("INSERT INTO users (username, password, role) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $username, $password, $role);

if ($stmt->execute()) {
    echo "✅ User berhasil ditambahkan<br>";

    // Kirim email notifikasi
    $subject = "Akun Baru Anda di Sistem Monitoring";
    $body = "
        <h3>Halo, $username!</h3>
        <p>Akun Anda berhasil dibuat di sistem monitoring jaringan.</p>
        <p><strong>Username:</strong> $username</p>
        <p><strong>Password:</strong> admin123</p>
        <p>Silakan login untuk mengakses dashboard.</p>
    ";

    if (kirimEmail($email, $subject, $body)) {
        echo "📧 Email notifikasi berhasil dikirim ke $email";
    } else {
        echo "❌ Gagal mengirim email ke $email";
    }

} else {
    echo "❌ Gagal menambahkan user (mungkin username sudah ada)";
}
?>
