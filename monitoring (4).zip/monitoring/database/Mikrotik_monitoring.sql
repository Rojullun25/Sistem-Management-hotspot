
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50),
    password VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    activity TEXT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE interfaces (
    id INT AUTO_INCREMENT PRIMARY KEY,
    interface_name VARCHAR(100),
    type VARCHAR(50),
    status VARCHAR(20),
    last_updated DATETIME
);

CREATE TABLE bandwidth_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    interface_id INT,
    rx BIGINT,
    tx BIGINT,
    logged_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
