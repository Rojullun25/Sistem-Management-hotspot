<?php
session_start();
require_once("config.php");

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    die("❌ Akses ditolak.");
}

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("❌ ID user tidak valid.");
}

$id = intval($_GET['id']);
$error = $success = "";

// Ambil user dari DB
$stmt = $mysqli->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user) {
    die("❌ User tidak ditemukan.");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $password = trim($_POST['password']);
    $role = $_POST['role'];

    if (empty($password)) {
        $error = "⚠️ Password wajib diisi.";
    } elseif (!in_array($role, ['admin', 'teknisi', 'viewer'])) {
        $error = "⚠️ Role tidak valid.";
    } else {
        $hashed_password = password_hash($password, PASSWORD_BCRYPT);
        $stmt = $mysqli->prepare("UPDATE users SET password = ?, role = ? WHERE id = ?");
        if ($stmt) {
            $stmt->bind_param("ssi", $hashed_password, $role, $id);
            if ($stmt->execute()) {
                $success = "✅ User berhasil diperbarui.";
                // Refresh data
                $user['role'] = $role;
            } else {
                $error = "❌ Gagal memperbarui user.";
            }
            $stmt->close();
        } else {
            $error = "❌ Query gagal disiapkan.";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit User</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="container mt-5">
    <h2>Edit User: <?= htmlspecialchars($user['username']) ?></h2>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="alert alert-success">
            <?= $success ?> <a href='manage_users.php' class='btn btn-sm btn-primary ms-3'>🔙 Kembali</a>
        </div>
    <?php endif; ?>

    <form method="post">
        <div class="mb-3">
            <label>Username:</label>
            <input type="text" class="form-control" value="<?= htmlspecialchars($user['username']) ?>" disabled>
        </div>

        <div class="mb-3">
            <label>Password Baru:</label>
            <input type="password" name="password" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Role:</label>
            <select name="role" class="form-control" required>
                <option value="admin" <?= $user['role'] == 'admin' ? 'selected' : '' ?>>Admin</option>
                <option value="teknisi" <?= $user['role'] == 'teknisi' ? 'selected' : '' ?>>Teknisi</option>
                <option value="viewer" <?= $user['role'] == 'viewer' ? 'selected' : '' ?>>Viewer</option>
            </select>
        </div>

        <button type="submit" class="btn btn-success">💾 Simpan Perubahan</button>
        <a href="manage_users.php" class="btn btn-secondary">🔙 Batal</a>
    </form>
</body>
</html>
