<?php
// Script untuk auto sync yang bisa dijalankan dengan cron job

require_once("sync_mikrotik.php");

// Konfigurasi auto sync
$config = [
    'sync_interval' => 300, // 5 menit
    'max_execution_time' => 120, // 2 menit
    'log_file' => 'sync.log'
];

// Set execution time limit
set_time_limit($config['max_execution_time']);

// Function untuk logging
function writeLog($message, $logFile = 'sync.log') {
    $timestamp = date('Y-m-d H:i:s');
    $logMessage = "[{$timestamp}] {$message}\n";
    file_put_contents($logFile, $logMessage, FILE_APPEND | LOCK_EX);
}

// Cek apakah sync sedang berjalan
$lockFile = 'sync.lock';
if (file_exists($lockFile)) {
    $lockTime = filemtime($lockFile);
    if (time() - $lockTime < $config['max_execution_time']) {
        writeLog("Sync masih berjalan, skip...", $config['log_file']);
        exit;
    } else {
        // Lock file sudah expired, hapus
        unlink($lockFile);
    }
}

// Buat lock file
touch($lockFile);

try {
    writeLog("Memulai auto sync...", $config['log_file']);
    
    $sync = new MikroTikSync($mysqli);
    $results = $sync->fullSync();
    
    writeLog("Auto sync berhasil: " . json_encode($results), $config['log_file']);
    
} catch (Exception $e) {
    writeLog("Auto sync gagal: " . $e->getMessage(), $config['log_file']);
} finally {
    // Hapus lock file
    if (file_exists($lockFile)) {
        unlink($lockFile);
    }
}
?>