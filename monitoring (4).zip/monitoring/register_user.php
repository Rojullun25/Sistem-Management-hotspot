<?php
session_start();
require_once("config.php");

// Cek hanya admin yang bisa akses
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    die("❌ Akses ditolak. Hanya admin yang bisa menambahkan user.");
}

$error = $success = '';
$username = $password = $role = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $role = $_POST['role'];

    if (empty($username) || empty($password)) {
        $error = "Username dan password wajib diisi.";
    } elseif (!in_array($role, ['admin', 'teknisi', 'viewer'])) {
        $error = "Role tidak valid.";
    } else {
        // Cek apakah username sudah ada
        $cek_stmt = $mysqli->prepare("SELECT id FROM users WHERE username = ?");
        $cek_stmt->bind_param("s", $username);
        $cek_stmt->execute();
        $cek_stmt->store_result();

        if ($cek_stmt->num_rows > 0) {
            $error = "❌ Username sudah digunakan. Silakan pilih username lain.";
        } else {
            $hashed_password = password_hash($password, PASSWORD_BCRYPT);
            $stmt = $mysqli->prepare("INSERT INTO users (username, password, role) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $username, $hashed_password, $role);
            if ($stmt->execute()) {
                $success = "✅ User berhasil ditambahkan ke DB dan MikroTik.";
                $username = $password = $role = ''; // Kosongkan form setelah sukses

                // Tambah user ke MikroTik
                require_once("routeros_api.class.php");
                $API = new RouterosAPI();
                if ($API->connect(MT_HOST, MT_USER, MT_PASS)) {
                    $API->comm("/ip/hotspot/user/add", [
                        "name" => $_POST['username'],
                        "password" => $_POST['password'],
                        "profile" => "default"
                    ]);
                    $API->disconnect();
                }
            } else {
                $error = "❌ Gagal menambahkan user ke database.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Tambah User Baru</title>
    <link rel="stylesheet" href="sidebar.css">
    <link rel="stylesheet" href="form-style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    
    <div class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <h3><i class="fas fa-tachometer-alt me-2"></i>DASHBOARD</h3>
        </div>
        <ul class="sidebar-nav">
            <li><a href="index.php"><span class="icon"><i class="fas fa-tachometer-alt"></i></span>Dashboard</a></li>
            <li><a href="interface.php"><span class="icon"><i class="fas fa-network-wired"></i></span>Network Interface</a></li>
            <li><a href="hotspot.php"><span class="icon"><i class="fas fa-wifi"></i></span>Hotspot Monitor</a></li>
            <li><a href="register_user.php"><span class="icon"><i class="fas fa-user-plus"></i></span>Tambah User</a></li>
            <li><a href="manage_users.php"><span class="icon"><i class="fas fa-users-cog"></i></span>Kelola User</a></li>
            <li><a href="export.php" class="active"><span class="icon"><i class="fas fa-download"></i></span>Export Data</a></li>
            <li><a href="logout.php"><span class="icon"><i class="fas fa-sign-out-alt"></i></span>Logout</a></li>
        </ul>
    </div>
    
    <div class="main-content">
        <div class="content-wrapper">
            <!-- Alert Messages -->
            <?php if ($error): ?>
                <div class="custom-alert alert-error">
                    <div class="alert-icon">
                        <i class="fas fa-exclamation-triangle"></i>
                    </div>
                    <div class="alert-content">
                        <strong>Error!</strong>
                        <p><?= $error ?></p>
                    </div>
                </div>
            <?php elseif ($success): ?>
                <div class="custom-alert alert-success">
                    <div class="alert-icon">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <div class="alert-content">
                        <strong>Berhasil!</strong>
                        <p><?= $success ?></p>
                    </div>
                </div>
                <div class="success-actions">
                    <a href="index.php" class="btn btn-secondary">
                        <i class="fas fa-arrow-left me-2"></i>Kembali ke Dashboard
                    </a>
                    <a href="register_user.php" class="btn btn-primary">
                        <i class="fas fa-plus me-2"></i>Tambah User Lagi
                    </a>
                </div>
            <?php endif; ?>

            <!-- Form Card -->
            <div class="form-card">
                <div class="form-header">
                    <h3><i class="fas fa-user-circle me-2"></i>Informasi User</h3>
                    <p>Lengkapi form di bawah untuk menambahkan user baru</p>
                </div>
                
                <form method="post" class="user-form">
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">
                                <i class="fas fa-user me-2"></i>Username
                            </label>
                            <div class="input-wrapper">
                                <input type="text" 
                                       name="username" 
                                       class="form-input" 
                                       required 
                                       value="<?= htmlspecialchars($username) ?>"
                                       placeholder="Masukkan username">
                                <div class="input-icon">
                                    <i class="fas fa-user"></i>
                                </div>
                            </div>
                            <small class="form-help">Username harus unik dan mudah diingat</small>
                        </div>

                        <div class="form-group">
                            <label class="form-label">
                                <i class="fas fa-lock me-2"></i>Password
                            </label>
                            <div class="input-wrapper">
                                <input type="password" 
                                       name="password" 
                                       class="form-input" 
                                       required
                                       placeholder="Masukkan password">
                                <div class="input-icon">
                                    <i class="fas fa-lock"></i>
                                </div>
                                <button type="button" class="password-toggle" onclick="togglePassword()">
                                    <i class="fas fa-eye" id="password-icon"></i>
                                </button>
                            </div>
                            <small class="form-help">Gunakan password yang kuat minimal 6 karakter</small>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label">
                            <i class="fas fa-user-tag me-2"></i>Role Pengguna
                        </label>
                        <div class="select-wrapper">
                            <select name="role" class="form-select" required>
                                <option value="">-- Pilih Role Pengguna --</option>
                                <option value="admin" <?= $role === 'admin' ? 'selected' : '' ?>>
                                    👑 Admin - Akses penuh sistem
                                </option>
                                <option value="teknisi" <?= $role === 'teknisi' ? 'selected' : '' ?>>
                                    🔧 Teknisi - Akses konfigurasi
                                </option>
                                <option value="viewer" <?= $role === 'viewer' ? 'selected' : '' ?>>
                                    👁️ Viewer - Hanya melihat data
                                </option>
                            </select>
                            <div class="select-icon">
                                <i class="fas fa-chevron-down"></i>
                            </div>
                        </div>
                        <small class="form-help">Pilih level akses yang sesuai untuk pengguna</small>
                    </div>

                    <div class="form-actions">
                        <button type="reset" class="btn btn-secondary">
                            <i class="fas fa-undo me-2"></i>Reset Form
                        </button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-user-plus me-2"></i>Tambah User
                        </button>
                    </div>
                </form>
            </div>

            <!-- Info Cards -->
            <div class="info-cards">
                <div class="info-card">
                    <div class="info-icon admin">
                        <i class="fas fa-crown"></i>
                    </div>
                    <div class="info-content">
                        <h4>Admin</h4>
                        <p>Akses penuh ke semua fitur sistem termasuk mengelola user dan konfigurasi</p>
                    </div>
                </div>
                
                <div class="info-card">
                    <div class="info-icon teknisi">
                        <i class="fas fa-tools"></i>
                    </div>
                    <div class="info-content">
                        <h4>Teknisi</h4>
                        <p>Dapat mengakses dan mengkonfigurasi perangkat MikroTik serta melihat data</p>
                    </div>
                </div>
                
                <div class="info-card">
                    <div class="info-icon viewer">
                        <i class="fas fa-eye"></i>
                    </div>
                    <div class="info-content">
                        <h4>Viewer</h4>
                        <p>Hanya dapat melihat dashboard dan data monitoring tanpa akses konfigurasi</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        function toggleSidebar() {
            document.getElementById('sidebar').classList.toggle('active');
        }
        
        function togglePassword() {
            const passwordInput = document.querySelector('input[name="password"]');
            const passwordIcon = document.getElementById('password-icon');
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                passwordIcon.className = 'fas fa-eye-slash';
            } else {
                passwordInput.type = 'password';
                passwordIcon.className = 'fas fa-eye';
            }
        }
    </script>
</body>
</html>