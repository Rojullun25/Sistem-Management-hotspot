<?php
require_once('config.php');
echo "✅ Koneksi ke DB dan konfigurasi berhasil!";
?>