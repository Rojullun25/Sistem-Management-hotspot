<?php
require_once("config.php");
$result = $mysqli->query("SELECT * FROM bandwidth_logs ORDER BY logged_at DESC LIMIT 10");

$rx = $tx = $time = [];
while ($row = $result->fetch_assoc()) {
    $rx[] = $row['rx'];
    $tx[] = $row['tx'];
    $time[] = date('H:i:s', strtotime($row['logged_at']));
}

echo json_encode([
    'rx' => array_reverse($rx),
    'tx' => array_reverse($tx),
    'time' => array_reverse($time)
]);
?>
