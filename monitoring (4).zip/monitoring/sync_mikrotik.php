<?php
require_once("config.php");
require_once("functions.php");
require_once("routeros_api.class.php");

class MikroTikSync {
    private $mysqli;
    private $api;
    
    public function __construct($mysqli) {
        $this->mysqli = $mysqli;
        $this->api = new RouterosAPI();
    }
    
    public function connect() {
        if (!$this->api->connect(MT_HOST, MT_USER, MT_PASS)) {
            throw new Exception("Gagal koneksi ke MikroTik");
        }
        return true;
    }
    
    public function disconnect() {
        $this->api->disconnect();
    }
    
    // =============================================
    // SYNC INTERFACES
    // =============================================
    public function syncInterfaces() {
        echo "🔄 Sinkronisasi Interfaces...\n";
        
        $interfaces = $this->api->comm("/interface/print");
        $synced = 0;
        $updated = 0;
        
        foreach ($interfaces as $iface) {
            $name = $iface['name'] ?? '';
            $type = $iface['type'] ?? '';
            $mac = $iface['mac-address'] ?? '';
            $mtu = isset($iface['mtu']) ? (int)$iface['mtu'] : 1500;
            $running = ($iface['running'] ?? 'false') === 'true';
            $disabled = ($iface['disabled'] ?? 'false') === 'true';
            $comment = $iface['comment'] ?? '';
            
            if (empty($name)) continue;
            
            // Cek apakah interface sudah ada
            $stmt = $this->mysqli->prepare("SELECT id FROM interfaces WHERE interface_name = ?");
            $stmt->bind_param("s", $name);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                // Update existing interface
                $update_stmt = $this->mysqli->prepare("
                    UPDATE interfaces SET 
                        interface_type = ?, 
                        mac_address = ?, 
                        mtu = ?, 
                        is_running = ?, 
                        is_enabled = ?, 
                        comment = ?,
                        updated_at = CURRENT_TIMESTAMP,
                        last_seen = CURRENT_TIMESTAMP
                    WHERE interface_name = ?
                ");
                $enabled = !$disabled;
                $update_stmt->bind_param("ssiiiss", $type, $mac, $mtu, $running, $enabled, $comment, $name);
                $update_stmt->execute();
                $updated++;
            } else {
                // Insert new interface
                $insert_stmt = $this->mysqli->prepare("
                    INSERT INTO interfaces (interface_name, interface_type, mac_address, mtu, is_running, is_enabled, comment) 
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ");
                $enabled = !$disabled;
                $insert_stmt->bind_param("ssiiiss", $name, $type, $mac, $mtu, $running, $enabled, $comment);
                $insert_stmt->execute();
                $synced++;
            }
        }
        
        echo "✅ Interfaces: {$synced} baru, {$updated} diupdate\n";
        return ['new' => $synced, 'updated' => $updated];
    }
    
    // =============================================
    // SYNC HOTSPOT USERS
    // =============================================
    public function syncHotspotUsers() {
        echo "🔄 Sinkronisasi Hotspot Users...\n";
        
        $users = $this->api->comm("/ip/hotspot/user/print");
        $synced = 0;
        $updated = 0;
        
        // Tandai semua user sebagai tidak aktif dulu
        $this->mysqli->query("UPDATE hotspot_users SET is_disabled = TRUE, updated_at = CURRENT_TIMESTAMP");
        
        foreach ($users as $user) {
            $username = $user['name'] ?? '';
            $password = $user['password'] ?? '';
            $profile = $user['profile'] ?? 'default';
            $server = $user['server'] ?? 'hotspot1';
            $disabled = ($user['disabled'] ?? 'false') === 'true';
            $comment = $user['comment'] ?? '';
            $limit_uptime = $user['limit-uptime'] ?? '';
            $limit_bytes_in = isset($user['limit-bytes-in']) ? (int)$user['limit-bytes-in'] : 0;
            $limit_bytes_out = isset($user['limit-bytes-out']) ? (int)$user['limit-bytes-out'] : 0;
            $limit_bytes_total = isset($user['limit-bytes-total']) ? (int)$user['limit-bytes-total'] : 0;
            
            if (empty($username)) continue;
            
            // Cek apakah user sudah ada
            $stmt = $this->mysqli->prepare("SELECT id FROM hotspot_users WHERE username = ?");
            $stmt->bind_param("s", $username);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                // Update existing user
                $update_stmt = $this->mysqli->prepare("
                    UPDATE hotspot_users SET 
                        password = ?, 
                        profile = ?, 
                        server = ?, 
                        limit_uptime = ?, 
                        limit_bytes_in = ?, 
                        limit_bytes_out = ?, 
                        limit_bytes_total = ?,
                        is_disabled = ?, 
                        comment = ?,
                        updated_at = CURRENT_TIMESTAMP
                    WHERE username = ?
                ");
                $update_stmt->bind_param("ssssiiiiis", $password, $profile, $server, $limit_uptime, 
                                       $limit_bytes_in, $limit_bytes_out, $limit_bytes_total, 
                                       $disabled, $comment, $username);
                $update_stmt->execute();
                $updated++;
            } else {
                // Insert new user
                $insert_stmt = $this->mysqli->prepare("
                    INSERT INTO hotspot_users (username, password, profile, server, limit_uptime, 
                                             limit_bytes_in, limit_bytes_out, limit_bytes_total, 
                                             is_disabled, comment) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ");
                $insert_stmt->bind_param("ssssiiiiis", $username, $password, $profile, $server, 
                                       $limit_uptime, $limit_bytes_in, $limit_bytes_out, 
                                       $limit_bytes_total, $disabled, $comment);
                $insert_stmt->execute();
                $synced++;
            }
        }
        
        echo "✅ Hotspot Users: {$synced} baru, {$updated} diupdate\n";
        return ['new' => $synced, 'updated' => $updated];
    }
    
    // =============================================
    // SYNC HOTSPOT ACTIVE SESSIONS
    // =============================================
    public function syncHotspotActiveSessions() {
        echo "🔄 Sinkronisasi Hotspot Active Sessions...\n";
        
        $sessions = $this->api->comm("/ip/hotspot/active/print");
        $synced = 0;
        
        // Hapus semua session lama
        $this->mysqli->query("DELETE FROM hotspot_active_sessions");
        
        foreach ($sessions as $session) {
            $mikrotik_id = $session['.id'] ?? '';
            $username = $session['user'] ?? '';
            $ip_address = $session['address'] ?? '';
            $mac_address = $session['mac-address'] ?? '';
            $server = $session['server'] ?? 'hotspot1';
            $login_time = $this->parseTime($session['login-time'] ?? '');
            $uptime = $session['uptime'] ?? '00:00:00';
            $session_time_left = $session['session-time-left'] ?? '';
            $idle_time = $session['idle-time'] ?? '00:00:00';
            $bytes_in = isset($session['bytes-in']) ? (int)$session['bytes-in'] : 0;
            $bytes_out = isset($session['bytes-out']) ? (int)$session['bytes-out'] : 0;
            $packets_in = isset($session['packets-in']) ? (int)$session['packets-in'] : 0;
            $packets_out = isset($session['packets-out']) ? (int)$session['packets-out'] : 0;
            $radius = ($session['radius'] ?? 'false') === 'true';
            $blocked = ($session['blocked'] ?? 'false') === 'true';
            
            if (empty($mikrotik_id) || empty($username)) continue;
            
            $insert_stmt = $this->mysqli->prepare("
                INSERT INTO hotspot_active_sessions 
                (mikrotik_id, username, ip_address, mac_address, server, login_time, uptime, 
                 session_time_left, idle_time, bytes_in, bytes_out, packets_in, packets_out, 
                 radius, blocked) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $insert_stmt->bind_param("ssssssssiiiiibb", $mikrotik_id, $username, $ip_address, 
                                   $mac_address, $server, $login_time, $uptime, $session_time_left, 
                                   $idle_time, $bytes_in, $bytes_out, $packets_in, $packets_out, 
                                   $radius, $blocked);
            $insert_stmt->execute();
            $synced++;
        }
        
        echo "✅ Active Sessions: {$synced} session aktif\n";
        return ['active' => $synced];
    }
    
    // =============================================
    // SYNC HOTSPOT PROFILES
    // =============================================
    public function syncHotspotProfiles() {
        echo "🔄 Sinkronisasi Hotspot Profiles...\n";
        
        $profiles = $this->api->comm("/ip/hotspot/user/profile/print");
        $synced = 0;
        $updated = 0;
        
        foreach ($profiles as $profile) {
            $name = $profile['name'] ?? '';
            $rate_limit = $profile['rate-limit'] ?? '';
            $session_timeout = $profile['session-timeout'] ?? '';
            $idle_timeout = $profile['idle-timeout'] ?? '';
            $keepalive_timeout = $profile['keepalive-timeout'] ?? '';
            $status_autorefresh = $profile['status-autorefresh'] ?? '';
            $shared_users = isset($profile['shared-users']) ? (int)$profile['shared-users'] : 1;
            $mac_cookie_timeout = $profile['mac-cookie-timeout'] ?? '';
            $address_pool = $profile['address-pool'] ?? '';
            $transparent_proxy = ($profile['transparent-proxy'] ?? 'false') === 'true';
            $bind_mac_address = ($profile['bind-mac-address'] ?? 'false') === 'true';
            
            if (empty($name)) continue;
            
            // Cek apakah profile sudah ada
            $stmt = $this->mysqli->prepare("SELECT id FROM hotspot_profiles WHERE profile_name = ?");
            $stmt->bind_param("s", $name);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                // Update existing profile
                $update_stmt = $this->mysqli->prepare("
                    UPDATE hotspot_profiles SET 
                        rate_limit = ?, session_timeout = ?, idle_timeout = ?, 
                        keepalive_timeout = ?, status_autorefresh = ?, shared_users = ?, 
                        mac_cookie_timeout = ?, address_pool = ?, transparent_proxy = ?, 
                        bind_mac_address = ?, updated_at = CURRENT_TIMESTAMP
                    WHERE profile_name = ?
                ");
                $update_stmt->bind_param("sssssissbbs", $rate_limit, $session_timeout, $idle_timeout, 
                                       $keepalive_timeout, $status_autorefresh, $shared_users, 
                                       $mac_cookie_timeout, $address_pool, $transparent_proxy, 
                                       $bind_mac_address, $name);
                $update_stmt->execute();
                $updated++;
            } else {
                // Insert new profile
                $insert_stmt = $this->mysqli->prepare("
                    INSERT INTO hotspot_profiles 
                    (profile_name, rate_limit, session_timeout, idle_timeout, keepalive_timeout, 
                     status_autorefresh, shared_users, mac_cookie_timeout, address_pool, 
                     transparent_proxy, bind_mac_address) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ");
                $insert_stmt->bind_param("sssssissbb", $name, $rate_limit, $session_timeout, 
                                       $idle_timeout, $keepalive_timeout, $status_autorefresh, 
                                       $shared_users, $mac_cookie_timeout, $address_pool, 
                                       $transparent_proxy, $bind_mac_address);
                $insert_stmt->execute();
                $synced++;
            }
        }
        
        echo "✅ Hotspot Profiles: {$synced} baru, {$updated} diupdate\n";
        return ['new' => $synced, 'updated' => $updated];
    }
    
    // =============================================
    // SYNC HOTSPOT SERVERS
    // =============================================
    public function syncHotspotServers() {
        echo "🔄 Sinkronisasi Hotspot Servers...\n";
        
        $servers = $this->api->comm("/ip/hotspot/print");
        $synced = 0;
        $updated = 0;
        
        foreach ($servers as $server) {
            $name = $server['name'] ?? '';
            $interface = $server['interface'] ?? '';
            $address_pool = $server['address-pool'] ?? '';
            $profile = $server['profile'] ?? 'default';
            $login_page = $server['login-page'] ?? 'login.html';
            $domain = $server['domain'] ?? '';
            $certificate = $server['certificate'] ?? 'none';
            $disabled = ($server['disabled'] ?? 'false') === 'true';
            
            if (empty($name)) continue;
            
            // Cek apakah server sudah ada
            $stmt = $this->mysqli->prepare("SELECT id FROM hotspot_servers WHERE server_name = ?");
            $stmt->bind_param("s", $name);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                // Update existing server
                $update_stmt = $this->mysqli->prepare("
                    UPDATE hotspot_servers SET 
                        interface_name = ?, address_pool = ?, profile = ?, 
                        login_page = ?, domain = ?, certificate = ?, 
                        is_disabled = ?, updated_at = CURRENT_TIMESTAMP
                    WHERE server_name = ?
                ");
                $update_stmt->bind_param("ssssssbs", $interface, $address_pool, $profile, 
                                       $login_page, $domain, $certificate, $disabled, $name);
                $update_stmt->execute();
                $updated++;
            } else {
                // Insert new server
                $insert_stmt = $this->mysqli->prepare("
                    INSERT INTO hotspot_servers 
                    (server_name, interface_name, address_pool, profile, login_page, 
                     domain, certificate, is_disabled) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ");
                $insert_stmt->bind_param("ssssssb", $name, $interface, $address_pool, 
                                       $profile, $login_page, $domain, $certificate, $disabled);
                $insert_stmt->execute();
                $synced++;
            }
        }
        
        echo "✅ Hotspot Servers: {$synced} baru, {$updated} diupdate\n";
        return ['new' => $synced, 'updated' => $updated];
    }
    
    // =============================================
    // SYNC WIRELESS INTERFACES
    // =============================================
    public function syncWirelessInterfaces() {
        echo "🔄 Sinkronisasi Wireless Interfaces...\n";
        
        $wireless = $this->api->comm("/interface/wireless/print");
        $synced = 0;
        $updated = 0;
        
        foreach ($wireless as $wlan) {
            $name = $wlan['name'] ?? '';
            $ssid = $wlan['ssid'] ?? '';
            $frequency = $wlan['frequency'] ?? '';
            $band = $wlan['band'] ?? '';
            $channel_width = $wlan['channel-width'] ?? '';
            $wireless_protocol = $wlan['wireless-protocol'] ?? '';
            $security_profile = $wlan['security-profile'] ?? '';
            $mode = $wlan['mode'] ?? '';
            $disabled = ($wlan['disabled'] ?? 'false') === 'true';
            $tx_power = isset($wlan['tx-power']) ? (int)$wlan['tx-power'] : null;
            $antenna_gain = isset($wlan['antenna-gain']) ? (int)$wlan['antenna-gain'] : null;
            $distance = $wlan['distance'] ?? 'indoors';
            
            if (empty($name)) continue;
            
            // Cek apakah wireless interface sudah ada
            $stmt = $this->mysqli->prepare("SELECT id FROM wireless_interfaces WHERE interface_name = ?");
            $stmt->bind_param("s", $name);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                // Update existing wireless interface
                $update_stmt = $this->mysqli->prepare("
                    UPDATE wireless_interfaces SET 
                        ssid = ?, frequency = ?, band = ?, channel_width = ?, 
                        wireless_protocol = ?, security_profile = ?, mode = ?, 
                        is_disabled = ?, tx_power = ?, antenna_gain = ?, 
                        distance = ?, updated_at = CURRENT_TIMESTAMP
                    WHERE interface_name = ?
                ");
                $update_stmt->bind_param("sssssssbiiis", $ssid, $frequency, $band, $channel_width, 
                                       $wireless_protocol, $security_profile, $mode, $disabled, 
                                       $tx_power, $antenna_gain, $distance, $name);
                $update_stmt->execute();
                $updated++;
            } else {
                // Insert new wireless interface
                $insert_stmt = $this->mysqli->prepare("
                    INSERT INTO wireless_interfaces 
                    (interface_name, ssid, frequency, band, channel_width, wireless_protocol, 
                     security_profile, mode, is_disabled, tx_power, antenna_gain, distance) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ");
                $insert_stmt->bind_param("sssssssbiiis", $name, $ssid, $frequency, $band, 
                                       $channel_width, $wireless_protocol, $security_profile, 
                                       $mode, $disabled, $tx_power, $antenna_gain, $distance);
                $insert_stmt->execute();
                $synced++;
            }
        }
        
        echo "✅ Wireless Interfaces: {$synced} baru, {$updated} diupdate\n";
        return ['new' => $synced, 'updated' => $updated];
    }
    
    // =============================================
    // SYNC BANDWIDTH LOGS
    // =============================================
    public function syncBandwidthLogs() {
        echo "🔄 Sinkronisasi Bandwidth Logs...\n";
        
        $interfaces = $this->api->comm("/interface/print");
        $logged = 0;
        
        foreach ($interfaces as $iface) {
            $name = $iface['name'] ?? '';
            $rx_byte = isset($iface['rx-byte']) ? (int)$iface['rx-byte'] : 0;
            $tx_byte = isset($iface['tx-byte']) ? (int)$iface['tx-byte'] : 0;
            $rx_packet = isset($iface['rx-packet']) ? (int)$iface['rx-packet'] : 0;
            $tx_packet = isset($iface['tx-packet']) ? (int)$iface['tx-packet'] : 0;
            $rx_error = isset($iface['rx-error']) ? (int)$iface['rx-error'] : 0;
            $tx_error = isset($iface['tx-error']) ? (int)$iface['tx-error'] : 0;
            
            if (empty($name)) continue;
            
            // Ambil interface_id dari database
            $stmt = $this->mysqli->prepare("SELECT id FROM interfaces WHERE interface_name = ?");
            $stmt->bind_param("s", $name);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($row = $result->fetch_assoc()) {
                $interface_id = $row['id'];
                
                // Insert bandwidth log
                $insert_stmt = $this->mysqli->prepare("
                    INSERT INTO bandwidth_logs 
                    (interface_id, rx, tx, rx_packets, tx_packets, rx_errors, tx_errors) 
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ");
                $insert_stmt->bind_param("iiiiiii", $interface_id, $rx_byte, $tx_byte, 
                                       $rx_packet, $tx_packet, $rx_error, $tx_error);
                $insert_stmt->execute();
                $logged++;
            }
        }
        
        echo "✅ Bandwidth Logs: {$logged} log ditambahkan\n";
        return ['logged' => $logged];
    }
    
    // =============================================
    // FULL SYNC - Sinkronisasi semua data
    // =============================================
    public function fullSync() {
        $start_time = microtime(true);
        echo "🚀 Memulai Full Sync dengan MikroTik...\n";
        echo "📅 " . date('Y-m-d H:i:s') . "\n";
        echo str_repeat("=", 50) . "\n";
        
        try {
            $this->connect();
            
            $results = [];
            $results['interfaces'] = $this->syncInterfaces();
            $results['hotspot_users'] = $this->syncHotspotUsers();
            $results['hotspot_sessions'] = $this->syncHotspotActiveSessions();
            $results['hotspot_profiles'] = $this->syncHotspotProfiles();
            $results['hotspot_servers'] = $this->syncHotspotServers();
            $results['wireless'] = $this->syncWirelessInterfaces();
            $results['bandwidth'] = $this->syncBandwidthLogs();
            
            $this->disconnect();
            
            $end_time = microtime(true);
            $duration = round($end_time - $start_time, 2);
            
            echo str_repeat("=", 50) . "\n";
            echo "✅ Full Sync selesai dalam {$duration} detik\n";
            
            // Log ke system_logs
            $this->logSyncActivity($results, $duration);
            
            return $results;
            
        } catch (Exception $e) {
            echo "❌ Error: " . $e->getMessage() . "\n";
            $this->disconnect();
            throw $e;
        }
    }
    
    // =============================================
    // HELPER FUNCTIONS
    // =============================================
    private function parseTime($timeStr) {
        if (empty($timeStr)) {
            return date('Y-m-d H:i:s');
        }
        
        // Parse MikroTik time format
        // Contoh: "jan/02/1970 07:00:00" atau "07:00:00"
        if (strpos($timeStr, '/') !== false) {
            return date('Y-m-d H:i:s', strtotime($timeStr));
        } else {
            return date('Y-m-d') . ' ' . $timeStr;
        }
    }
    
    private function logSyncActivity($results, $duration) {
        $description = "Full sync completed in {$duration}s. ";
        $description .= "Interfaces: " . ($results['interfaces']['new'] + $results['interfaces']['updated']) . ", ";
        $description .= "Hotspot Users: " . ($results['hotspot_users']['new'] + $results['hotspot_users']['updated']) . ", ";
        $description .= "Active Sessions: " . $results['hotspot_sessions']['active'] . ", ";
        $description .= "Bandwidth Logs: " . $results['bandwidth']['logged'];
        
        $stmt = $this->mysqli->prepare("
            INSERT INTO system_logs (user_id, action, description, ip_address) 
            VALUES (NULL, 'MIKROTIK_SYNC', ?, '127.0.0.1')
        ");
        $stmt->bind_param("s", $description);
        $stmt->execute();
    }
}

// =============================================
// EKSEKUSI SCRIPT
// =============================================
if (php_sapi_name() === 'cli' || isset($_GET['sync'])) {
    try {
        $sync = new MikroTikSync($mysqli);
        $results = $sync->fullSync();
        
        if (isset($_GET['sync'])) {
            header('Content-Type: application/json');
            echo json_encode([
                'success' => true,
                'message' => 'Sinkronisasi berhasil',
                'results' => $results,
                'timestamp' => date('Y-m-d H:i:s')
            ]);
        }
        
    } catch (Exception $e) {
        if (isset($_GET['sync'])) {
            header('Content-Type: application/json');
            echo json_encode([
                'success' => false,
                'message' => $e->getMessage(),
                'timestamp' => date('Y-m-d H:i:s')
            ]);
        } else {
            echo "❌ Error: " . $e->getMessage() . "\n";
        }
    }
}
?>