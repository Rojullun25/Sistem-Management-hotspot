<?php
session_start();
require_once("config.php");
require_once("send_mail.php"); // pastikan file ini sudah ada dan benar

$error = '';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $stmt = $mysqli->prepare("SELECT id, password, role FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($id, $hashed_password, $role);
        $stmt->fetch();

        if (password_verify($password, $hashed_password)) {
            // ✅ Set session login
            $_SESSION['user_id'] = $id;
            $_SESSION['username'] = $username;
            $_SESSION['role'] = $role;

            // ✅ Kirim notifikasi email login berhasil
            $email_tujuan = "creatorsunda022@gmail.com"; // GANTI ke email tujuan sebenarnya
            $subject = "Login Berhasil - $username";
            $isiPesan = '
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f4f6f9;
      margin: 0;
      padding: 0;
    }
    .container {
      background-color: #ffffff;
      max-width: 600px;
      margin: 30px auto;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 0 15px rgba(0,0,0,0.05);
    }
    h2 {
      color: #2c3e50;
      margin-top: 0;
    }
    .info-table {
      width: 100%;
      border-collapse: collapse;
      margin: 20px 0;
    }
    .info-table td {
      padding: 8px 10px;
      vertical-align: top;
    }
    .info-table td:first-child {
      font-weight: bold;
      color: #34495e;
      width: 140px;
    }
    .button {
      display: inline-block;
      padding: 10px 20px;
      margin-top: 20px;
      background-color: #2ecc71;
      color: white;
      text-decoration: none;
      border-radius: 5px;
      font-weight: bold;
    }
    .footer {
      margin-top: 30px;
      font-size: 12px;
      color: #999;
      text-align: center;
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>✅ Login Berhasil</h2>
    <p>Halo Admin,</p>
    <p>User <strong>' . htmlspecialchars($username) . '</strong> telah berhasil login ke sistem Monitoring MikroTik.</p>
    
    <table class="info-table">
      <tr><td>🕒 Waktu Login:</td><td>' . date('d-m-Y H:i:s') . '</td></tr>
      <tr><td>🌐 IP Address:</td><td>' . $_SERVER['REMOTE_ADDR'] . '</td></tr>
      <tr><td>👤 Role:</td><td>' . htmlspecialchars($role) . '</td></tr>
    </table>

    <a class="button" href="http://localhost/monitoring-v02/index.php">Buka Dashboard</a>

    <div class="footer">
      Email ini dikirim secara otomatis oleh sistem Monitoring MikroTik.<br>
      Jangan balas email ini.
    </div>
  </div>
</body>
</html>';

            kirimEmail($email_tujuan, $subject, $isiPesan);

            // ✅ Redirect ke dashboard
            header("Location: index.php");
            exit();
        } else {
            $error = "❌ Password salah!";
        }
    } else {
        $error = "❌ User tidak ditemukan!";
    }
}
?>

<!-- ✅ Tampilan HTML Login -->
<link rel="stylesheet" href="login-style.css">
<div class="login-container">
    <form method="post">
        <h3 class="login-title">Hotspot Management System </h3>
        
        <?php if($error): ?>
            <div class="error-message"><?= $error ?></div>
        <?php endif; ?>
        
        <div class="form-group">
            <label class="form-label">Username:</label>
            <input type="text" name="username" class="form-control" required>
        </div>
        
        <div class="form-group">
            <label class="form-label">Password:</label>
            <input type="password" name="password" class="form-control" required>
        </div>
        
        <button type="submit" class="btn btn-login">Login</button>
    </form>
</div>
