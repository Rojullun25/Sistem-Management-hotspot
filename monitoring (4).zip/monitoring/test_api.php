<?php
require_once('routeros_api.class.php');

$API = new RouterosAPI();
$API->debug = true;

if ($API->connect('10.10.10.1', 'monitoring', '123')) {
    echo "✅ Terhubung ke MikroTik!<br>";
    $data = $API->comm("/interface/print");
    echo "<pre>"; print_r($data); echo "</pre>";
    $API->disconnect();
} else {
    echo "❌ Gagal konek ke MikroTik";
}