<?php
define('MT_HOST', '10.10.10.1');
define('MT_USER', 'admin');
define('MT_PASS', '123');

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'hotspot_monitoring');

$mysqli = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($mysqli->connect_error) {
    die('Koneksi DB gagal: ' . $mysqli->connect_error);
}
?>