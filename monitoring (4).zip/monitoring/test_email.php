<?php
require 'send_mail.php'; // Pastikan path ini benar

// Uji kirim email
$hasil = kirimEmail('ahmad.fatih89@gmail.com', 'Tes Kirim Email', '✅ Sistem berhasil mengirim email!');

if ($hasil) {
    echo "✅ Email berhasil dikirim!";
} else {
    echo "❌ Gagal mengirim email.";
}
