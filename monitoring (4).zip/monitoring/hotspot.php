<?php
session_start();
require_once("config.php");
require_once("functions.php");

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$role = $_SESSION['role'];
$username = $_SESSION['username'];

// Handle disconnect user action
if (isset($_POST['disconnect_user']) && $_POST['disconnect_user']) {
    $userId = $_POST['user_id'];
    if (disconnectHotspotUser($userId)) {
        $success_message = "User berhasil didisconnect!";
    } else {
        $error_message = "Gagal disconnect user!";
    }
}

// Get hotspot data
$hotspotData = getHotspotRealTimeData();
$activeUsers = $hotspotData['active_users'];
$statistics = $hotspotData['statistics'];
$bandwidthSummary = $hotspotData['bandwidth_summary'];
$servers = $hotspotData['servers'];
$profiles = $hotspotData['profiles'];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Hotspot Monitor System MikroTik</title>
    <link rel="stylesheet" href="sidebar.css">
    <link rel="stylesheet" href="hotspot-style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <meta http-equiv="refresh" content="30">
</head>
<body>
   <div class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <h3><i class="fas fa-tachometer-alt me-2"></i>DASHBOARD</h3>
        </div>
        <ul class="sidebar-nav">
            <li><a href="index.php"><span class="icon"><i class="fas fa-tachometer-alt"></i></span>Dashboard</a></li>
            <li><a href="interface.php"><span class="icon"><i class="fas fa-network-wired"></i></span>Network Interface</a></li>
            <li><a href="hotspot.php"><span class="icon"><i class="fas fa-wifi"></i></span>Hotspot Monitor</a></li>
            <li><a href="register_user.php"><span class="icon"><i class="fas fa-user-plus"></i></span>Tambah User</a></li>
            <li><a href="manage_users.php"><span class="icon"><i class="fas fa-users-cog"></i></span>Kelola User</a></li>
            <li><a href="export.php" class="active"><span class="icon"><i class="fas fa-download"></i></span>Export Data</a></li>
            <li><a href="logout.php"><span class="icon"><i class="fas fa-sign-out-alt"></i></span>Logout</a></li>
        </ul>
    </div>
    
    <div class="main-content">
        <div class="content-wrapper">
            <!-- Page Header -->
            <div class="page-header">
                <div class="header-content">
                    <div class="header-icon">
                        <i class="fas fa-wifi"></i>
                    </div>
                    <div class="header-text">
                        <h1>Hotspot Monitor</h1>
                        <p>Monitor dan kelola user hotspot MikroTik secara real-time</p>
                    </div>
                </div>
                <div class="header-actions">
                    <button class="btn btn-primary" onclick="refreshData()">
                        <i class="fas fa-sync-alt me-2"></i>Refresh
                    </button>
                    <div class="auto-refresh">
                        <i class="fas fa-clock me-1"></i>Auto refresh: 30s
                    </div>
                </div>
            </div>

            <!-- Alert Messages -->
            <?php if (isset($success_message)): ?>
                <div class="custom-alert alert-success">
                    <div class="alert-icon">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <div class="alert-content">
                        <strong>Berhasil!</strong>
                        <p><?= $success_message ?></p>
                    </div>
                </div>
            <?php endif; ?>

            <?php if (isset($error_message)): ?>
                <div class="custom-alert alert-error">
                    <div class="alert-icon">
                        <i class="fas fa-exclamation-triangle"></i>
                    </div>
                    <div class="alert-content">
                        <strong>Error!</strong>
                        <p><?= $error_message ?></p>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Statistics Cards -->
            <div class="stats-grid">
                <div class="stat-card active-users">
                    <div class="stat-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="stat-content">
                        <h3><?= $statistics['active_users'] ?></h3>
                        <p>User Aktif</p>
                        <div class="stat-trend">
                            <i class="fas fa-arrow-up"></i>
                            <span>Online sekarang</span>
                        </div>
                    </div>
                </div>

                <div class="stat-card total-users">
                    <div class="stat-icon">
                        <i class="fas fa-user-friends"></i>
                    </div>
                    <div class="stat-content">
                        <h3><?= $statistics['total_users'] ?></h3>
                        <p>Total User</p>
                        <div class="stat-trend">
                            <i class="fas fa-database"></i>
                            <span>Terdaftar</span>
                        </div>
                    </div>
                </div>

                <div class="stat-card bandwidth-in">
                    <div class="stat-icon">
                        <i class="fas fa-download"></i>
                    </div>
                    <div class="stat-content">
                        <h3><?= $bandwidthSummary['total_bytes_in_formatted'] ?></h3>
                        <p>Total Download</p>
                        <div class="stat-trend">
                            <i class="fas fa-arrow-down"></i>
                            <span>Incoming</span>
                        </div>
                    </div>
                </div>

                <div class="stat-card bandwidth-out">
                    <div class="stat-icon">
                        <i class="fas fa-upload"></i>
                    </div>
                    <div class="stat-content">
                        <h3><?= $bandwidthSummary['total_bytes_out_formatted'] ?></h3>
                        <p>Total Upload</p>
                        <div class="stat-trend">
                            <i class="fas fa-arrow-up"></i>
                            <span>Outgoing</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Active Users Table -->
            <div class="data-card">
                <div class="card-header">
                    <div class="header-left">
                        <h3><i class="fas fa-users me-2"></i>User Hotspot Aktif</h3>
                        <span class="user-count"><?= count($activeUsers) ?> user online</span>
                    </div>
                    <div class="header-right">
                        <div class="search-box">
                            <input type="text" id="searchUser" placeholder="Cari user..." onkeyup="searchUsers()">
                            <i class="fas fa-search"></i>
                        </div>
                    </div>
                </div>

                <div class="table-container">
                    <table class="users-table" id="usersTable">
                        <thead>
                            <tr>
                                <th><i class="fas fa-hashtag"></i></th>
                                <th><i class="fas fa-user me-1"></i>Username</th>
                                <th><i class="fas fa-globe me-1"></i>IP Address</th>
                                <th><i class="fas fa-ethernet me-1"></i>MAC Address</th>
                                <th><i class="fas fa-clock me-1"></i>Login Time</th>
                                <th><i class="fas fa-stopwatch me-1"></i>Uptime</th>
                                <th><i class="fas fa-download me-1"></i>Download</th>
                                <th><i class="fas fa-upload me-1"></i>Upload</th>
                                <th><i class="fas fa-tachometer-alt me-1"></i>Speed</th>
                                <th><i class="fas fa-cogs me-1"></i>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($activeUsers)): ?>
                                <tr class="no-data">
                                    <td colspan="10">
                                        <div class="no-data-content">
                                            <i class="fas fa-wifi fa-3x"></i>
                                            <h4>Tidak ada user aktif</h4>
                                            <p>Belum ada user yang terhubung ke hotspot</p>
                                        </div>
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($activeUsers as $index => $user): ?>
                                    <tr class="user-row">
                                        <td class="row-number"><?= $index + 1 ?></td>
                                        <td class="username">
                                            <div class="user-info">
                                                <div class="user-avatar">
                                                    <i class="fas fa-user"></i>
                                                </div>
                                                <div class="user-details">
                                                    <strong><?= htmlspecialchars($user['user']) ?></strong>
                                                    <?php if ($user['radius']): ?>
                                                        <span class="badge radius"></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="ip-address">
                                            <span class="ip"><?= $user['address'] ?></span>
                                        </td>
                                        <td class="mac-address">
                                            <span class="mac"><?= $user['mac_address'] ?></span>
                                        </td>
                                        <td class="login-time">
                                            <i class="fas fa-sign-in-alt me-1"></i>
                                            <?= $user['login_time'] ?>
                                        </td>
                                        <td class="uptime">
                                            <span class="uptime-badge"><?= $user['uptime'] ?></span>
                                        </td>
                                        <td class="download">
                                            <div class="bandwidth-info">
                                                <span class="bytes"><?= $user['bytes_in_formatted'] ?></span>
                                                <small class="packets"><?= number_format($user['packets_in']) ?> packets</small>
                                            </div>
                                        </td>
                                        <td class="upload">
                                            <div class="bandwidth-info">
                                                <span class="bytes"><?= $user['bytes_out_formatted'] ?></span>
                                                <small class="packets"><?= number_format($user['packets_out']) ?> packets</small>
                                            </div>
                                        </td>
                                        <td class="speed">
                                            <div class="speed-info">
                                                <div class="speed-down">
                                                    <i class="fas fa-arrow-down"></i>
                                                    <?= $user['avg_speed_in'] ?>
                                                </div>
                                                <div class="speed-up">
                                                    <i class="fas fa-arrow-up"></i>
                                                    <?= $user['avg_speed_out'] ?>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="actions">
                                            <div class="action-buttons">
                                                <button class="btn-action btn-info" title="Detail User" onclick="showUserDetail('<?= htmlspecialchars($user['user']) ?>')">
                                                    <i class="fas fa-info-circle"></i>
                                                </button>
                                                <?php if ($role === 'admin' || $role === 'teknisi'): ?>
                                                    <form method="post" style="display: inline;" onsubmit="return confirm('Yakin ingin disconnect user <?= htmlspecialchars($user['user']) ?>?')">
                                                        <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                                                        <button type="submit" name="disconnect_user" value="1" class="btn-action btn-danger" title="Disconnect User">
                                                            <i class="fas fa-sign-out-alt"></i>
                                                        </button>
                                                    </form>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Server & Profile Info -->
            <div class="info-grid">
                <div class="info-card">
                    <div class="info-header">
                        <h4><i class="fas fa-server me-2"></i>Hotspot Servers</h4>
                    </div>
                    <div class="info-content">
                        <?php if (empty($servers)): ?>
                            <p class="no-info">Tidak ada server hotspot aktif</p>
                        <?php else: ?>
                            <?php foreach ($servers as $server): ?>
                                <div class="server-item">
                                    <div class="server-icon">
                                        <i class="fas fa-server"></i>
                                    </div>
                                    <div class="server-details">
                                        <strong><?= $server['name'] ?? 'hotspot1' ?></strong>
                                        <small>Interface: <?= $server['interface'] ?? 'N/A' ?></small>
                                    </div>
                                    <div class="server-status">
                                        <span class="status-badge active">Active</span>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="info-card">
                    <div class="info-header">
                        <h4><i class="fas fa-id-card me-2"></i>User Profiles</h4>
                    </div>
                    <div class="info-content">
                        <?php if (empty($profiles)): ?>
                            <p class="no-info">Tidak ada profil user</p>
                        <?php else: ?>
                            <?php foreach (array_slice($profiles, 0, 5) as $profile): ?>
                                <div class="profile-item">
                                    <div class="profile-icon">
                                        <i class="fas fa-user-tag"></i>
                                    </div>
                                    <div class="profile-details">
                                        <strong><?= $profile['name'] ?? 'default' ?></strong>
                                        <small>
                                            Rate: <?= $profile['rate-limit'] ?? 'Unlimited' ?>
                                        </small>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- User Detail Modal -->
    <div id="userDetailModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-user-circle me-2"></i>Detail User</h3>
                <span class="close" onclick="closeModal()">&times;</span>
            </div>
            <div class="modal-body" id="userDetailContent">
                <!-- Content will be loaded here -->
            </div>
        </div>
    </div>
    
    <script>
        function toggleSidebar() {
            document.getElementById('sidebar').classList.toggle('active');
        }
        
        function refreshData() {
            location.reload();
        }
        
        function searchUsers() {
            const input = document.getElementById('searchUser');
            const filter = input.value.toLowerCase();
            const table = document.getElementById('usersTable');
            const rows = table.getElementsByTagName('tr');
            
            for (let i = 1; i < rows.length; i++) {
                const row = rows[i];
                const username = row.getElementsByClassName('username')[0];
                const ip = row.getElementsByClassName('ip-address')[0];
                const mac = row.getElementsByClassName('mac-address')[0];
                
                if (username || ip || mac) {
                    const usernameText = username ? username.textContent.toLowerCase() : '';
                    const ipText = ip ? ip.textContent.toLowerCase() : '';
                    const macText = mac ? mac.textContent.toLowerCase() : '';
                    
                    if (usernameText.includes(filter) || ipText.includes(filter) || macText.includes(filter)) {
                        row.style.display = '';
                    } else {
                        row.style.display = 'none';
                    }
                }
            }
        }
        
        function showUserDetail(username) {
            // Show modal with user details
            document.getElementById('userDetailModal').style.display = 'block';
            document.getElementById('userDetailContent').innerHTML = '<p>Loading user details...</p>';
            
            // Here you can add AJAX call to get detailed user info
            // For now, just show basic info
            setTimeout(() => {
                document.getElementById('userDetailContent').innerHTML = `
                    <div class="user-detail-info">
                        <h4>Username: ${username}</h4>
                        <p>Detail informasi user akan ditampilkan di sini...</p>
                    </div>
                `;
            }, 500);
        }
        
        function closeModal() {
            document.getElementById('userDetailModal').style.display = 'none';
        }
        
        // Close modal when clicking outside
        window.onclick = function(event) {
            const modal = document.getElementById('userDetailModal');
            if (event.target == modal) {
                modal.style.display = 'none';
            }
        }
        
        // Auto refresh countdown
        let refreshCountdown = 30;
        setInterval(() => {
            refreshCountdown--;
            if (refreshCountdown <= 0) {
                refreshCountdown = 30;
            }
            document.querySelector('.auto-refresh').innerHTML = `<i class="fas fa-clock me-1"></i>Auto refresh: ${refreshCountdown}s`;
        }, 1000);
    </script>
</body>
</html>